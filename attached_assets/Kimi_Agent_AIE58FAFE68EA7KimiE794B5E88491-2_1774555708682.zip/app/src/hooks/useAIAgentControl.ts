// Enhanced AI Agent Control Hook
// Inspired by AIOS, Agent Zero, E2B, Manus

import { useState, useCallback, useRef, useEffect } from 'react';
import type { AIAgent, AIControlCommand, ExternalAIResponse, AgentTask, AgentSession, AgentCapability } from '@/types/system';

interface AIAgentControlState {
  agents: AIAgent[];
  isListening: boolean;
  pendingCommands: AIControlCommand[];
  commandHistory: AIControlCommand[];
  apiEndpoint: string;
  tasks: AgentTask[];
  sessions: AgentSession[];
}

interface UseAIAgentControlOptions {
  onExecuteCommand?: (command: AIControlCommand) => Promise<any>;
  onAgentConnect?: (agent: AIAgent) => void;
  onAgentDisconnect?: (agentId: string) => void;
  onTaskCreated?: (task: AgentTask) => void;
  onTaskComplete?: (task: AgentTask) => void;
}

export function useAIAgentControl(options: UseAIAgentControlOptions = {}) {
  const [state, setState] = useState<AIAgentControlState>({
    agents: [
      {
        id: 'system-agent',
        name: 'Kimi System',
        type: 'system',
        status: 'idle',
        capabilities: ['computer-use', 'browser', 'terminal', 'files', 'code', 'vision', 'system'],
      },
      {
        id: 'local-agent',
        name: 'Kimi Local',
        type: 'local',
        status: 'idle',
        capabilities: ['chat', 'code', 'files', 'system', 'planning', 'memory'],
      },
    ],
    isListening: false,
    pendingCommands: [],
    commandHistory: [],
    apiEndpoint: '/api/ai-control',
    tasks: [],
    sessions: [],
  });

  const pollingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const heartbeatIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Register an external AI agent
  const registerAgent = useCallback((agent: Omit<AIAgent, 'id' | 'lastSeen'>): string => {
    const id = `agent-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const newAgent: AIAgent = { 
      ...agent, 
      id, 
      lastSeen: new Date(),
      status: 'idle',
    };
    
    setState(prev => ({
      ...prev,
      agents: [...prev.agents, newAgent],
    }));

    options.onAgentConnect?.(newAgent);
    
    return id;
  }, [options]);

  // Unregister an agent
  const unregisterAgent = useCallback((agentId: string) => {
    setState(prev => {
      const agent = prev.agents.find(a => a.id === agentId);
      if (agent) {
        options.onAgentDisconnect?.(agentId);
      }
      return {
        ...prev,
        agents: prev.agents.filter(a => a.id !== agentId),
      };
    });
  }, [options]);

  // Update agent status
  const updateAgentStatus = useCallback((agentId: string, status: AIAgent['status']) => {
    setState(prev => ({
      ...prev,
      agents: prev.agents.map(a => 
        a.id === agentId ? { ...a, status, lastSeen: new Date() } : a
      ),
    }));
  }, []);

  // Update agent capabilities
  const updateAgentCapabilities = useCallback((agentId: string, capabilities: AgentCapability[]) => {
    setState(prev => ({
      ...prev,
      agents: prev.agents.map(a => 
        a.id === agentId ? { ...a, capabilities } : a
      ),
    }));
  }, []);

  // Create a new agent session
  const createSession = useCallback((agentId: string): AgentSession => {
    const session: AgentSession = {
      id: `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      agentId,
      status: 'active',
      createdAt: new Date(),
      lastActivityAt: new Date(),
      context: {},
      history: [],
    };

    setState(prev => ({
      ...prev,
      sessions: [...prev.sessions, session],
    }));

    return session;
  }, []);

  // Close a session
  const closeSession = useCallback((sessionId: string) => {
    setState(prev => ({
      ...prev,
      sessions: prev.sessions.map(s => 
        s.id === sessionId ? { ...s, status: 'closed' as const } : s
      ),
    }));
  }, []);

  // Create a new task
  const createTask = useCallback((agentId: string, type: AgentTask['type'], description: string): AgentTask => {
    const task: AgentTask = {
      id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      agentId,
      type,
      status: 'pending',
      description,
      steps: [],
      createdAt: new Date(),
    };

    setState(prev => ({
      ...prev,
      tasks: [...prev.tasks, task],
    }));

    options.onTaskCreated?.(task);

    return task;
  }, [options]);

  // Start a task
  const startTask = useCallback((taskId: string) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => 
        t.id === taskId ? { ...t, status: 'running' as const, startedAt: new Date() } : t
      ),
    }));
  }, []);

  // Complete a task
  const completeTask = useCallback((taskId: string, result?: any) => {
    setState(prev => {
      const task = prev.tasks.find(t => t.id === taskId);
      if (task) {
        const completedTask: AgentTask = {
          ...task,
          status: 'completed',
          completedAt: new Date(),
          result,
        };
        options.onTaskComplete?.(completedTask);
      }

      return {
        ...prev,
        tasks: prev.tasks.map(t => 
          t.id === taskId ? { ...t, status: 'completed' as const, completedAt: new Date(), result } : t
        ),
      };
    });
  }, [options]);

  // Fail a task
  const failTask = useCallback((taskId: string, error: string) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => 
        t.id === taskId ? { ...t, status: 'failed' as const, completedAt: new Date(), error } : t
      ),
    }));
  }, []);

  // Add step to task
  const addTaskStep = useCallback((taskId: string, step: { type: AgentTask['steps'][0]['type']; content: string; data?: any }) => {
    setState(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => 
        t.id === taskId 
          ? { 
              ...t, 
              steps: [...t.steps, { 
                ...step, 
                id: `step-${Date.now()}`, 
                timestamp: new Date() 
              }] 
            } 
          : t
      ),
    }));
  }, []);

  // Start listening for external AI commands via WebSocket
  const startListening = useCallback((port: number = 7777) => {
    setState(prev => ({ ...prev, isListening: true }));

    // Setup WebSocket connection
    const setupWebSocket = () => {
      try {
        wsRef.current = new WebSocket(`ws://localhost:${port}/ai-events`);
        
        wsRef.current.onopen = () => {
          console.log('WebSocket connected');
          // Send heartbeat
          heartbeatIntervalRef.current = setInterval(() => {
            wsRef.current?.send(JSON.stringify({ type: 'heartbeat', timestamp: Date.now() }));
          }, 30000);
        };
        
        wsRef.current.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.type === 'command') {
              handleIncomingCommand(data.command);
            } else if (data.type === 'register') {
              // Register new agent
              registerAgent({
                name: data.agentName || 'External Agent',
                type: 'external',
                status: 'idle',
                capabilities: data.capabilities || ['computer-use'],
                endpoint: data.endpoint,
                apiKey: data.apiKey,
              });
            }
          } catch (e) {
            console.error('Failed to parse WebSocket message:', e);
          }
        };
        
        wsRef.current.onerror = (error) => {
          console.error('WebSocket error:', error);
          // Fallback to polling
          startPolling(port);
        };

        wsRef.current.onclose = () => {
          console.log('WebSocket closed');
          if (heartbeatIntervalRef.current) {
            clearInterval(heartbeatIntervalRef.current);
          }
        };
      } catch (e) {
        console.log('WebSocket not available, falling back to polling');
        startPolling(port);
      }
    };

    // Fallback polling mechanism
    const startPolling = (port: number) => {
      pollingIntervalRef.current = setInterval(async () => {
        try {
          const response = await fetch(`http://localhost:${port}/ai-commands/pending`);
          if (response.ok) {
            const commands = await response.json();
            commands.forEach((cmd: AIControlCommand) => handleIncomingCommand(cmd));
          }
        } catch (e) {
          // Silent fail - endpoint might not be available
        }
      }, 1000);
    };

    setupWebSocket();
    
    // Also set up window message listener for iframe/postMessage communication
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'AI_CONTROL_COMMAND') {
        handleIncomingCommand(event.data.command);
      } else if (event.data?.type === 'AI_REGISTER_AGENT') {
        registerAgent(event.data.agent);
      }
    };
    
    window.addEventListener('message', handleMessage);
    
    return () => {
      window.removeEventListener('message', handleMessage);
      wsRef.current?.close();
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current);
      }
    };
  }, [registerAgent]);

  // Stop listening
  const stopListening = useCallback(() => {
    setState(prev => ({ ...prev, isListening: false }));
    wsRef.current?.close();
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
    }
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
    }
  }, []);

  // Handle incoming command from external AI
  const handleIncomingCommand = useCallback(async (command: AIControlCommand): Promise<any> => {
    setState(prev => ({
      ...prev,
      pendingCommands: [...prev.pendingCommands, command],
    }));

    try {
      const result = await options.onExecuteCommand?.(command);
      
      setState(prev => ({
        ...prev,
        pendingCommands: prev.pendingCommands.filter(c => c.id !== command.id),
        commandHistory: [...prev.commandHistory, { ...command, result }],
      }));

      // Send response back if callback URL provided
      if (command.callbackUrl) {
        await fetch(command.callbackUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            commandId: command.id,
            success: true,
            data: result,
            timestamp: new Date(),
          }),
        });
      }

      return result;
    } catch (error) {
      setState(prev => ({
        ...prev,
        pendingCommands: prev.pendingCommands.filter(c => c.id !== command.id),
        commandHistory: [...prev.commandHistory, { ...command, error }],
      }));

      // Send error response
      if (command.callbackUrl) {
        await fetch(command.callbackUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            commandId: command.id,
            success: false,
            error: (error as Error).message,
            timestamp: new Date(),
          }),
        });
      }

      throw error;
    }
  }, [options]);

  // Execute a command locally
  const executeCommand = useCallback(async (command: Omit<AIControlCommand, 'id' | 'timestamp'>): Promise<any> => {
    const fullCommand: AIControlCommand = {
      ...command,
      id: `cmd-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
    };

    return handleIncomingCommand(fullCommand);
  }, [handleIncomingCommand]);

  // Send command to external agent
  const sendToAgent = useCallback(async (agentId: string, action: string, params: any): Promise<ExternalAIResponse> => {
    const agent = state.agents.find(a => a.id === agentId);
    if (!agent) {
      return { success: false, error: 'Agent not found', timestamp: new Date() };
    }

    if (!agent.endpoint) {
      return { success: false, error: 'Agent has no endpoint configured', timestamp: new Date() };
    }

    try {
      const response = await fetch(agent.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(agent.apiKey && { 'Authorization': `Bearer ${agent.apiKey}` }),
        },
        body: JSON.stringify({ action, params }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return { success: true, data, timestamp: new Date() };
    } catch (error) {
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date(),
      };
    }
  }, [state.agents]);

  // Get available agents
  const getAvailableAgents = useCallback(() => {
    return state.agents.filter(a => a.status === 'idle');
  }, [state.agents]);

  // Get agent by ID
  const getAgent = useCallback((agentId: string) => {
    return state.agents.find(a => a.id === agentId);
  }, [state.agents]);

  // Get active tasks
  const getActiveTasks = useCallback(() => {
    return state.tasks.filter(t => t.status === 'running' || t.status === 'pending');
  }, [state.tasks]);

  // Get tasks by agent
  const getTasksByAgent = useCallback((agentId: string) => {
    return state.tasks.filter(t => t.agentId === agentId);
  }, [state.tasks]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      wsRef.current?.close();
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current);
      }
    };
  }, []);

  return {
    agents: state.agents,
    isListening: state.isListening,
    pendingCommands: state.pendingCommands,
    commandHistory: state.commandHistory,
    apiEndpoint: state.apiEndpoint,
    tasks: state.tasks,
    sessions: state.sessions,
    registerAgent,
    unregisterAgent,
    updateAgentStatus,
    updateAgentCapabilities,
    createSession,
    closeSession,
    createTask,
    startTask,
    completeTask,
    failTask,
    addTaskStep,
    startListening,
    stopListening,
    executeCommand,
    sendToAgent,
    getAvailableAgents,
    getAgent,
    getActiveTasks,
    getTasksByAgent,
  };
}

// Command builders for common actions
export const AICommands = {
  mouse: {
    click: (x: number, y: number, button: 'left' | 'right' | 'middle' = 'left') => ({
      type: 'mouse' as const,
      action: 'click',
      params: { x, y, button },
    }),
    move: (x: number, y: number) => ({
      type: 'mouse' as const,
      action: 'move',
      params: { x, y },
    }),
    drag: (fromX: number, fromY: number, toX: number, toY: number) => ({
      type: 'mouse' as const,
      action: 'drag',
      params: { fromX, fromY, toX, toY },
    }),
    scroll: (deltaX: number, deltaY: number) => ({
      type: 'mouse' as const,
      action: 'scroll',
      params: { deltaX, deltaY },
    }),
  },
  keyboard: {
    type: (text: string) => ({
      type: 'keyboard' as const,
      action: 'type',
      params: { text },
    }),
    keypress: (key: string, modifiers?: string[]) => ({
      type: 'keyboard' as const,
      action: 'keypress',
      params: { key, modifiers },
    }),
    shortcut: (keys: string[]) => ({
      type: 'keyboard' as const,
      action: 'shortcut',
      params: { keys },
    }),
  },
  window: {
    open: (appType: string, title?: string) => ({
      type: 'window' as const,
      action: 'open',
      params: { appType, title },
    }),
    close: (windowId: string) => ({
      type: 'window' as const,
      action: 'close',
      params: { windowId },
    }),
    focus: (windowId: string) => ({
      type: 'window' as const,
      action: 'focus',
      params: { windowId },
    }),
    move: (windowId: string, x: number, y: number) => ({
      type: 'window' as const,
      action: 'move',
      params: { windowId, x, y },
    }),
    resize: (windowId: string, width: number, height: number) => ({
      type: 'window' as const,
      action: 'resize',
      params: { windowId, width, height },
    }),
    minimize: (windowId: string) => ({
      type: 'window' as const,
      action: 'minimize',
      params: { windowId },
    }),
    maximize: (windowId: string) => ({
      type: 'window' as const,
      action: 'maximize',
      params: { windowId },
    }),
  },
  system: {
    screenshot: () => ({
      type: 'system' as const,
      action: 'screenshot',
      params: {},
    }),
    getStats: () => ({
      type: 'system' as const,
      action: 'getStats',
      params: {},
    }),
    setComputeMode: (mode: string) => ({
      type: 'system' as const,
      action: 'setComputeMode',
      params: { mode },
    }),
    execute: (command: string) => ({
      type: 'system' as const,
      action: 'execute',
      params: { command },
    }),
  },
  file: {
    read: (path: string) => ({
      type: 'file' as const,
      action: 'read',
      params: { path },
    }),
    write: (path: string, content: string) => ({
      type: 'file' as const,
      action: 'write',
      params: { path, content },
    }),
    delete: (path: string) => ({
      type: 'file' as const,
      action: 'delete',
      params: { path },
    }),
    list: (path: string) => ({
      type: 'file' as const,
      action: 'list',
      params: { path },
    }),
    createFolder: (path: string) => ({
      type: 'file' as const,
      action: 'createFolder',
      params: { path },
    }),
  },
  browser: {
    navigate: (url: string) => ({
      type: 'browser' as const,
      action: 'navigate',
      params: { url },
    }),
    search: (query: string) => ({
      type: 'browser' as const,
      action: 'search',
      params: { query },
    }),
    getContent: () => ({
      type: 'browser' as const,
      action: 'getContent',
      params: {},
    }),
    click: (selector: string) => ({
      type: 'browser' as const,
      action: 'click',
      params: { selector },
    }),
    type: (selector: string, text: string) => ({
      type: 'browser' as const,
      action: 'type',
      params: { selector, text },
    }),
  },
  computerUse: {
    screenshot: () => ({
      type: 'computer-use' as const,
      action: 'screenshot',
      params: {},
    }),
    click: (x: number, y: number) => ({
      type: 'computer-use' as const,
      action: 'click',
      params: { x, y },
    }),
    doubleClick: (x: number, y: number) => ({
      type: 'computer-use' as const,
      action: 'doubleClick',
      params: { x, y },
    }),
    type: (text: string) => ({
      type: 'computer-use' as const,
      action: 'type',
      params: { text },
    }),
    keypress: (key: string, modifiers?: string[]) => ({
      type: 'computer-use' as const,
      action: 'keypress',
      params: { key, modifiers },
    }),
    scroll: (deltaX: number, deltaY: number) => ({
      type: 'computer-use' as const,
      action: 'scroll',
      params: { deltaX, deltaY },
    }),
    wait: (ms: number) => ({
      type: 'computer-use' as const,
      action: 'wait',
      params: { ms },
    }),
  },
};
