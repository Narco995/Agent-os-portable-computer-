import { useState, useCallback, useRef } from 'react';
import type { Window, AppType } from '@/types/system';

const DEFAULT_WINDOW_SIZE = {
  terminal: { width: 800, height: 500 },
  files: { width: 900, height: 600 },
  browser: { width: 1200, height: 800 },
  editor: { width: 1000, height: 700 },
  settings: { width: 700, height: 500 },
  aichat: { width: 450, height: 650 },
  python: { width: 800, height: 600 },
  hardware: { width: 800, height: 600 },
  airouter: { width: 900, height: 650 },
  desktop: { width: 0, height: 0 },
  vnc: { width: 1024, height: 768 },
};

const DEFAULT_WINDOW_POSITION = {
  terminal: { x: 100, y: 50 },
  files: { x: 150, y: 80 },
  browser: { x: 200, y: 100 },
  editor: { x: 120, y: 60 },
  settings: { x: 300, y: 150 },
  aichat: { x: 800, y: 50 },
  python: { x: 180, y: 90 },
  hardware: { x: 250, y: 120 },
  airouter: { x: 200, y: 80 },
  desktop: { x: 0, y: 0 },
  vnc: { x: 100, y: 50 },
};

export function useWindowManager() {
  const [windows, setWindows] = useState<Window[]>([]);
  const [focusedWindowId, setFocusedWindowId] = useState<string | null>(null);
  const zIndexCounter = useRef(100);

  const generateId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  const openWindow = useCallback((appType: AppType, title?: string, content?: any) => {
    const id = generateId();
    const defaultSize = DEFAULT_WINDOW_SIZE[appType];
    const defaultPos = DEFAULT_WINDOW_POSITION[appType];
    
    // Offset position based on existing windows of same type
    const sameTypeWindows = windows.filter(w => w.appType === appType);
    const offset = sameTypeWindows.length * 30;
    
    const newWindow: Window = {
      id,
      title: title || getDefaultTitle(appType),
      appType,
      x: defaultPos.x + offset,
      y: defaultPos.y + offset,
      width: defaultSize.width,
      height: defaultSize.height,
      isMinimized: false,
      isMaximized: false,
      isFocused: true,
      zIndex: ++zIndexCounter.current,
      content,
    };

    setWindows(prev => [...prev.map(w => ({ ...w, isFocused: false })), newWindow]);
    setFocusedWindowId(id);
    return id;
  }, [windows]);

  const closeWindow = useCallback((id: string) => {
    setWindows(prev => {
      const filtered = prev.filter(w => w.id !== id);
      if (focusedWindowId === id && filtered.length > 0) {
        const lastWindow = filtered[filtered.length - 1];
        setFocusedWindowId(lastWindow.id);
        return filtered.map(w => w.id === lastWindow.id ? { ...w, isFocused: true } : w);
      }
      return filtered;
    });
    if (focusedWindowId === id) {
      setFocusedWindowId(null);
    }
  }, [focusedWindowId]);

  const focusWindow = useCallback((id: string) => {
    setWindows(prev => prev.map(w => ({
      ...w,
      isFocused: w.id === id,
      zIndex: w.id === id ? ++zIndexCounter.current : w.zIndex,
    })));
    setFocusedWindowId(id);
  }, []);

  const minimizeWindow = useCallback((id: string) => {
    setWindows(prev => prev.map(w => 
      w.id === id ? { ...w, isMinimized: true, isFocused: false } : w
    ));
    if (focusedWindowId === id) {
      const remaining = windows.filter(w => w.id !== id && !w.isMinimized);
      if (remaining.length > 0) {
        focusWindow(remaining[remaining.length - 1].id);
      } else {
        setFocusedWindowId(null);
      }
    }
  }, [windows, focusedWindowId, focusWindow]);

  const restoreWindow = useCallback((id: string) => {
    setWindows(prev => prev.map(w => 
      w.id === id ? { ...w, isMinimized: false, isFocused: true, zIndex: ++zIndexCounter.current } : { ...w, isFocused: false }
    ));
    setFocusedWindowId(id);
  }, []);

  const maximizeWindow = useCallback((id: string) => {
    setWindows(prev => prev.map(w => 
      w.id === id ? { ...w, isMaximized: !w.isMaximized } : w
    ));
  }, []);

  const updateWindowPosition = useCallback((id: string, x: number, y: number) => {
    setWindows(prev => prev.map(w => 
      w.id === id ? { ...w, x, y } : w
    ));
  }, []);

  const updateWindowSize = useCallback((id: string, width: number, height: number) => {
    setWindows(prev => prev.map(w => 
      w.id === id ? { ...w, width, height } : w
    ));
  }, []);

  const updateWindowTitle = useCallback((id: string, title: string) => {
    setWindows(prev => prev.map(w => 
      w.id === id ? { ...w, title } : w
    ));
  }, []);

  const getWindowById = useCallback((id: string) => {
    return windows.find(w => w.id === id);
  }, [windows]);

  const getWindowsByType = useCallback((appType: AppType) => {
    return windows.filter(w => w.appType === appType);
  }, [windows]);

  return {
    windows,
    focusedWindowId,
    openWindow,
    closeWindow,
    focusWindow,
    minimizeWindow,
    restoreWindow,
    maximizeWindow,
    updateWindowPosition,
    updateWindowSize,
    updateWindowTitle,
    getWindowById,
    getWindowsByType,
  };
}

function getDefaultTitle(appType: AppType): string {
  const titles: Record<AppType, string> = {
    terminal: 'Terminal',
    files: 'File Manager',
    browser: 'Browser',
    editor: 'Text Editor',
    settings: 'Settings',
    aichat: 'AI Chat',
    python: 'Python IDE',
    hardware: 'Hardware Monitor',
    airouter: 'AI Router',
    desktop: 'Desktop',
    vnc: 'Remote Desktop',
  };
  return titles[appType];
}
