import { useState, useEffect, useCallback, useRef } from 'react';
import type { HardwareStats, ComputeMode } from '@/types/system';

interface HardwareMonitorState {
  stats: HardwareStats;
  history: { timestamp: number; cpu: number; memory: number }[];
  computeMode: ComputeMode;
}

const INITIAL_STATS: HardwareStats = {
  cpu: {
    usage: 0,
    cores: navigator.hardwareConcurrency || 4,
    frequency: 2.4,
    temperature: 45,
  },
  memory: {
    used: 0,
    total: 0,
    percentage: 0,
  },
  gpu: {
    usage: 0,
    memory: 0,
    temperature: 40,
  },
  network: {
    status: 'online',
    downloadSpeed: 0,
    uploadSpeed: 0,
  },
  storage: {
    used: 0,
    total: 0,
  },
};

export function useHardwareMonitor() {
  const [state, setState] = useState<HardwareMonitorState>({
    stats: INITIAL_STATS,
    history: [],
    computeMode: 'local',
  });

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const networkSpeedRef = useRef({ lastDown: 0, lastUp: 0, lastTime: Date.now() });

  // Simulate realistic hardware stats
  const updateStats = useCallback(() => {
    setState(prev => {
      // Simulate CPU usage with some randomness but staying within realistic bounds
      const cpuVariation = (Math.random() - 0.5) * 10;
      const newCpuUsage = Math.max(5, Math.min(95, prev.stats.cpu.usage + cpuVariation));
      
      // Simulate temperature based on CPU usage
      const newTemp = 35 + (newCpuUsage * 0.4) + (Math.random() * 5);
      
      // Memory simulation
      const memoryVariation = (Math.random() - 0.5) * 0.5;
      const memoryPercentage = Math.max(20, Math.min(90, prev.stats.memory.percentage + memoryVariation));
      const totalMemory = 16; // GB
      const usedMemory = (totalMemory * memoryPercentage) / 100;
      
      // GPU simulation (if available)
      const gpuUsage = Math.max(0, Math.min(100, newCpuUsage * 0.7 + (Math.random() - 0.5) * 20));
      const gpuMemory = gpuUsage * 0.08; // GB
      const gpuTemp = 40 + (gpuUsage * 0.5) + (Math.random() * 3);

      // Network speed simulation
      const now = Date.now();
      const downloadSpeed = Math.random() * 50 + (Math.random() > 0.8 ? 100 : 0); // MB/s
      const uploadSpeed = Math.random() * 20 + (Math.random() > 0.9 ? 50 : 0);

      // Storage simulation
      const totalStorage = 512; // GB
      const usedStorage = 180 + Math.random() * 50;

      const newStats: HardwareStats = {
        cpu: {
          usage: Math.round(newCpuUsage),
          cores: prev.stats.cpu.cores,
          frequency: 2.4 + (newCpuUsage / 100) * 1.2,
          temperature: Math.round(newTemp),
        },
        memory: {
          used: Math.round(usedMemory * 100) / 100,
          total: totalMemory,
          percentage: Math.round(memoryPercentage),
        },
        gpu: {
          usage: Math.round(gpuUsage),
          memory: Math.round(gpuMemory * 100) / 100,
          temperature: Math.round(gpuTemp),
        },
        network: {
          status: navigator.onLine ? 'online' : 'offline',
          downloadSpeed: Math.round(downloadSpeed * 100) / 100,
          uploadSpeed: Math.round(uploadSpeed * 100) / 100,
        },
        storage: {
          used: Math.round(usedStorage),
          total: totalStorage,
        },
      };

      // Keep last 60 data points for history
      const newHistory = [
        ...prev.history.slice(-59),
        { timestamp: now, cpu: newStats.cpu.usage, memory: newStats.memory.percentage },
      ];

      networkSpeedRef.current = { lastDown: downloadSpeed, lastUp: uploadSpeed, lastTime: now };

      return {
        ...prev,
        stats: newStats,
        history: newHistory,
      };
    });
  }, []);

  // Set compute mode
  const setComputeMode = useCallback((mode: ComputeMode) => {
    setState(prev => ({ ...prev, computeMode: mode }));
  }, []);

  // Get performance summary
  const getPerformanceSummary = useCallback(() => {
    const { stats } = state;
    const avgCpu = state.history.reduce((sum, h) => sum + h.cpu, 0) / (state.history.length || 1);
    const avgMemory = state.history.reduce((sum, h) => sum + h.memory, 0) / (state.history.length || 1);
    
    return {
      cpuAverage: Math.round(avgCpu),
      memoryAverage: Math.round(avgMemory),
      currentStatus: stats.cpu.usage > 80 || stats.memory.percentage > 85 ? 'high' : 
                     stats.cpu.usage > 50 || stats.memory.percentage > 60 ? 'medium' : 'low',
      uptime: Math.floor(performance.now() / 1000),
    };
  }, [state]);

  // Start monitoring
  const startMonitoring = useCallback((interval: number = 1000) => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    intervalRef.current = setInterval(updateStats, interval);
  }, [updateStats]);

  // Stop monitoring
  const stopMonitoring = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  // Get NPU status (simulated)
  const getNPUStatus = useCallback(() => {
    const modes: ('idle' | 'active' | 'busy')[] = ['idle', 'active', 'busy'];
    const status = modes[Math.floor(Math.random() * modes.length)];
    return {
      status,
      utilization: status === 'idle' ? 0 : status === 'active' ? Math.random() * 50 + 20 : Math.random() * 30 + 70,
      model: 'Kimi-NPU v2.0',
    };
  }, []);

  // Initialize
  useEffect(() => {
    startMonitoring();
    
    // Listen for online/offline events
    const handleOnline = () => {
      setState(prev => ({
        ...prev,
        stats: { ...prev.stats, network: { ...prev.stats.network, status: 'online' } },
      }));
    };
    
    const handleOffline = () => {
      setState(prev => ({
        ...prev,
        stats: { ...prev.stats, network: { ...prev.stats.network, status: 'offline' } },
      }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      stopMonitoring();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [startMonitoring, stopMonitoring]);

  return {
    stats: state.stats,
    history: state.history,
    computeMode: state.computeMode,
    setComputeMode,
    getPerformanceSummary,
    getNPUStatus,
    startMonitoring,
    stopMonitoring,
  };
}
