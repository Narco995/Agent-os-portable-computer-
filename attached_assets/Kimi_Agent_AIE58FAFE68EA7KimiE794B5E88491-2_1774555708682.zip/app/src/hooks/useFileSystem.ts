import { useState, useCallback } from 'react';
import type { FileSystemItem } from '@/types/system';

const INITIAL_FILES: FileSystemItem[] = [
  { id: 'root', name: 'Home', type: 'folder', parentId: null, createdAt: new Date(), modifiedAt: new Date() },
  { id: 'docs', name: 'Documents', type: 'folder', parentId: 'root', createdAt: new Date(), modifiedAt: new Date() },
  { id: 'downloads', name: 'Downloads', type: 'folder', parentId: 'root', createdAt: new Date(), modifiedAt: new Date() },
  { id: 'pictures', name: 'Pictures', type: 'folder', parentId: 'root', createdAt: new Date(), modifiedAt: new Date() },
  { id: 'projects', name: 'Projects', type: 'folder', parentId: 'root', createdAt: new Date(), modifiedAt: new Date() },
  { id: 'welcome', name: 'welcome.txt', type: 'file', parentId: 'root', content: 'Welcome to Kimi OS Portable!\n\nThis is your personal portable computer that can be controlled by external AI agents.\n\nFeatures:\n- Terminal with full command support\n- File manager with drag-and-drop\n- Web browser with AI integration\n- Code editor with syntax highlighting\n- Hardware monitoring\n- Multi-mode compute (Local/Hybrid/Cloud)\n\nGet started by exploring the applications!', size: 312, createdAt: new Date(), modifiedAt: new Date() },
  { id: 'readme', name: 'README.md', type: 'file', parentId: 'projects', content: '# Kimi OS Portable\n\nA portable computer system controllable by external AI agents.\n\n## Quick Start\n\n1. Open Terminal - Execute commands\n2. Open Browser - Surf the web\n3. Open Editor - Write code\n4. Open AI Chat - Talk to AI\n\n## AI Control API\n\nConnect external AI agents via:\n- WebSocket: ws://localhost:7777\n- HTTP API: http://localhost:7777/api\n- PostMessage: window.postMessage()', size: 245, createdAt: new Date(), modifiedAt: new Date() },
  { id: 'main-py', name: 'main.py', type: 'file', parentId: 'projects', content: '#!/usr/bin/env python3\n\ndef main():\n    print("Hello from Kimi OS Portable!")\n    \n    # AI Agent Integration\n    agent = AIAgent()\n    agent.connect()\n    \n    # Execute tasks\n    result = agent.execute("browse_web", {"url": "https://kimi.com"})\n    print(f"Result: {result}")\n\nif __name__ == "__main__":\n    main()', size: 298, createdAt: new Date(), modifiedAt: new Date() },
  { id: 'config-json', name: 'config.json', type: 'file', parentId: 'projects', content: '{\n  "name": "Kimi OS Portable",\n  "version": "2.0.0",\n  "ai_control": {\n    "enabled": true,\n    "port": 7777,\n    "allow_external": true,\n    "agents": []\n  },\n  "compute": {\n    "mode": "hybrid",\n    "local_priority": true\n  }\n}', size: 234, createdAt: new Date(), modifiedAt: new Date() },
];

export function useFileSystem() {
  const [files, setFiles] = useState<FileSystemItem[]>(INITIAL_FILES);
  const [currentPath, setCurrentPath] = useState<string[]>(['root']);

  // Get current folder contents
  const getCurrentFolderContents = useCallback(() => {
    const currentFolderId = currentPath[currentPath.length - 1];
    return files.filter(f => f.parentId === currentFolderId);
  }, [files, currentPath]);

  // Navigate to folder
  const navigateToFolder = useCallback((folderId: string) => {
    const folder = files.find(f => f.id === folderId);
    if (folder && folder.type === 'folder') {
      setCurrentPath(prev => [...prev, folderId]);
    }
  }, [files]);

  // Navigate up
  const navigateUp = useCallback(() => {
    setCurrentPath(prev => prev.length > 1 ? prev.slice(0, -1) : prev);
  }, []);

  // Navigate to path
  const navigateToPath = useCallback((path: string[]) => {
    setCurrentPath(path);
  }, []);

  // Get breadcrumb path
  const getBreadcrumb = useCallback(() => {
    return currentPath.map(id => {
      const item = files.find(f => f.id === id);
      return { id, name: item?.name || id };
    });
  }, [currentPath, files]);

  // Create file
  const createFile = useCallback((name: string, content: string = '', parentId?: string) => {
    const folderId = parentId || currentPath[currentPath.length - 1];
    const newFile: FileSystemItem = {
      id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name,
      type: 'file',
      parentId: folderId,
      content,
      size: new Blob([content]).size,
      createdAt: new Date(),
      modifiedAt: new Date(),
    };
    setFiles(prev => [...prev, newFile]);
    return newFile.id;
  }, [currentPath]);

  // Create folder
  const createFolder = useCallback((name: string, parentId?: string) => {
    const folderId = parentId || currentPath[currentPath.length - 1];
    const newFolder: FileSystemItem = {
      id: `folder-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name,
      type: 'folder',
      parentId: folderId,
      createdAt: new Date(),
      modifiedAt: new Date(),
    };
    setFiles(prev => [...prev, newFolder]);
    return newFolder.id;
  }, [currentPath]);

  // Delete item
  const deleteItem = useCallback((id: string) => {
    setFiles(prev => {
      const toDelete = [id];
      const findChildren = (parentId: string) => {
        const children = prev.filter(f => f.parentId === parentId);
        children.forEach(child => {
          toDelete.push(child.id);
          if (child.type === 'folder') {
            findChildren(child.id);
          }
        });
      };
      findChildren(id);
      return prev.filter(f => !toDelete.includes(f.id));
    });
  }, []);

  // Rename item
  const renameItem = useCallback((id: string, newName: string) => {
    setFiles(prev => prev.map(f => 
      f.id === id ? { ...f, name: newName, modifiedAt: new Date() } : f
    ));
  }, []);

  // Read file
  const readFile = useCallback((id: string): FileSystemItem | undefined => {
    return files.find(f => f.id === id && f.type === 'file');
  }, [files]);

  // Write file
  const writeFile = useCallback((id: string, content: string) => {
    setFiles(prev => prev.map(f => 
      f.id === id ? { ...f, content, size: new Blob([content]).size, modifiedAt: new Date() } : f
    ));
  }, []);

  // Move item
  const moveItem = useCallback((id: string, newParentId: string) => {
    setFiles(prev => prev.map(f => 
      f.id === id ? { ...f, parentId: newParentId, modifiedAt: new Date() } : f
    ));
  }, []);

  // Copy item
  const copyItem = useCallback((id: string, newParentId: string) => {
    const item = files.find(f => f.id === id);
    if (!item) return;

    const copyRecursive = (itemToCopy: FileSystemItem, parentId: string) => {
      const newId = `${itemToCopy.type}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const newItem: FileSystemItem = {
        ...itemToCopy,
        id: newId,
        parentId,
        createdAt: new Date(),
        modifiedAt: new Date(),
      };
      
      setFiles(prev => [...prev, newItem]);

      if (itemToCopy.type === 'folder') {
        const children = files.filter(f => f.parentId === itemToCopy.id);
        children.forEach(child => copyRecursive(child, newId));
      }
    };

    copyRecursive(item, newParentId);
  }, [files]);

  // Search files
  const searchFiles = useCallback((query: string) => {
    const lowerQuery = query.toLowerCase();
    return files.filter(f => 
      f.name.toLowerCase().includes(lowerQuery) ||
      (f.type === 'file' && f.content?.toLowerCase().includes(lowerQuery))
    );
  }, [files]);

  // Get file path
  const getFilePath = useCallback((id: string): string => {
    const path: string[] = [];
    let currentId: string | null = id;
    
    while (currentId) {
      const item = files.find(f => f.id === currentId);
      if (item) {
        path.unshift(item.name);
        currentId = item.parentId;
      } else {
        break;
      }
    }
    
    return path.join('/') || '/';
  }, [files]);

  // Get total size
  const getTotalSize = useCallback(() => {
    return files
      .filter(f => f.type === 'file')
      .reduce((total, f) => total + (f.size || 0), 0);
  }, [files]);

  return {
    files,
    currentPath,
    getCurrentFolderContents,
    navigateToFolder,
    navigateUp,
    navigateToPath,
    getBreadcrumb,
    createFile,
    createFolder,
    deleteItem,
    renameItem,
    readFile,
    writeFile,
    moveItem,
    copyItem,
    searchFiles,
    getFilePath,
    getTotalSize,
  };
}
