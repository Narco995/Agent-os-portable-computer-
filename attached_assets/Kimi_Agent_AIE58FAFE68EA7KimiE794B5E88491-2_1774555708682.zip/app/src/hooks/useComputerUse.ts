// Computer-Use Agent Hook
// Inspired by OpenAI CUA, Claude Computer Use, E2B Desktop

import { useState, useCallback, useRef, useEffect } from 'react';
import type { ComputerAction, ComputerObservation, AgentTask, TaskStep } from '@/types/system';

interface ComputerUseState {
  isActive: boolean;
  currentTask: AgentTask | null;
  screenshot: string | null;
  cursorPosition: { x: number; y: number };
  isProcessing: boolean;
}

interface UseComputerUseOptions {
  onAction?: (action: ComputerAction) => void;
  onObservation?: (observation: ComputerObservation) => void;
  onTaskComplete?: (task: AgentTask) => void;
  onError?: (error: Error) => void;
}

export function useComputerUse(options: UseComputerUseOptions = {}) {
  const [state, setState] = useState<ComputerUseState>({
    isActive: false,
    currentTask: null,
    screenshot: null,
    cursorPosition: { x: 0, y: 0 },
    isProcessing: false,
  });

  const screenshotIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Capture screenshot of the desktop
  const captureScreenshot = useCallback(async (): Promise<string> => {
    try {
      // Use html2canvas to capture the desktop
      const element = document.getElementById('kimi-os-desktop');
      if (!element) return '';
      
      const html2canvas = (await import('html2canvas')).default;
      const canvas = await html2canvas(element, {
        scale: 0.5,
        useCORS: true,
        allowTaint: true,
        backgroundColor: null,
      });
      
      return canvas.toDataURL('image/jpeg', 0.8);
    } catch (error) {
      console.error('Screenshot capture failed:', error);
      return '';
    }
  }, []);

  // Execute a computer action
  const executeAction = useCallback(async (action: Omit<ComputerAction, 'id' | 'timestamp'>): Promise<ComputerObservation> => {
    const fullAction: ComputerAction = {
      ...action,
      id: `action-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
    };
    
    options.onAction?.(fullAction);

    setState(prev => ({ ...prev, isProcessing: true }));

    try {
      let result: any = null;

      switch (action.type) {
        case 'screenshot':
          result = await captureScreenshot();
          break;

        case 'click':
          await simulateClick(action.params.x, action.params.y, action.params.button || 'left');
          result = { clicked: true, x: action.params.x, y: action.params.y };
          break;

        case 'double_click':
          await simulateDoubleClick(action.params.x, action.params.y);
          result = { doubleClicked: true, x: action.params.x, y: action.params.y };
          break;

        case 'move':
          await simulateMouseMove(action.params.x, action.params.y);
          setState(prev => ({ ...prev, cursorPosition: { x: action.params.x, y: action.params.y } }));
          result = { moved: true, x: action.params.x, y: action.params.y };
          break;

        case 'drag':
          await simulateDrag(action.params.fromX, action.params.fromY, action.params.toX, action.params.toY);
          result = { dragged: true, from: { x: action.params.fromX, y: action.params.fromY }, to: { x: action.params.toX, y: action.params.toY } };
          break;

        case 'scroll':
          await simulateScroll(action.params.deltaX || 0, action.params.deltaY || 0);
          result = { scrolled: true, deltaX: action.params.deltaX, deltaY: action.params.deltaY };
          break;

        case 'type':
          await simulateType(action.params.text);
          result = { typed: true, text: action.params.text };
          break;

        case 'keypress':
          await simulateKeyPress(action.params.key, action.params.modifiers);
          result = { keyPressed: true, key: action.params.key, modifiers: action.params.modifiers };
          break;

        case 'wait':
          await new Promise(resolve => setTimeout(resolve, action.params.ms || 1000));
          result = { waited: true, ms: action.params.ms };
          break;

        case 'bash':
          // Execute bash command through terminal
          result = { executed: true, command: action.params.command };
          break;

        default:
          throw new Error(`Unknown action type: ${action.type}`);
      }

      // Capture screenshot after action
      const screenshot = await captureScreenshot();
      
      const observation: ComputerObservation = {
        screenshot,
        text: result ? JSON.stringify(result) : undefined,
        timestamp: new Date(),
      };

      setState(prev => ({ ...prev, screenshot, isProcessing: false }));
      options.onObservation?.(observation);

      return observation;
    } catch (error) {
      setState(prev => ({ ...prev, isProcessing: false }));
      options.onError?.(error as Error);
      throw error;
    }
  }, [captureScreenshot, options]);

  // Start a new computer-use task
  const startTask = useCallback(async (description: string, agentId: string): Promise<AgentTask> => {
    const task: AgentTask = {
      id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      agentId,
      type: 'computer-use',
      status: 'running',
      description,
      steps: [],
      createdAt: new Date(),
      startedAt: new Date(),
    };

    setState(prev => ({ ...prev, currentTask: task, isActive: true }));

    // Start continuous screenshot capture
    screenshotIntervalRef.current = setInterval(async () => {
      const screenshot = await captureScreenshot();
      setState(prev => ({ ...prev, screenshot }));
    }, 2000);

    return task;
  }, [captureScreenshot]);

  // Complete the current task
  const completeTask = useCallback((result?: any) => {
    setState(prev => {
      if (!prev.currentTask) return prev;
      
      const completedTask: AgentTask = {
        ...prev.currentTask,
        status: 'completed',
        completedAt: new Date(),
        result,
      };

      options.onTaskComplete?.(completedTask);

      // Stop screenshot capture
      if (screenshotIntervalRef.current) {
        clearInterval(screenshotIntervalRef.current);
        screenshotIntervalRef.current = null;
      }

      return {
        ...prev,
        currentTask: null,
        isActive: false,
      };
    });
  }, [options]);

  // Add a step to the current task
  const addTaskStep = useCallback((step: Omit<TaskStep, 'id' | 'timestamp'>) => {
    setState(prev => {
      if (!prev.currentTask) return prev;

      const newStep: TaskStep = {
        ...step,
        id: `step-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        timestamp: new Date(),
      };

      return {
        ...prev,
        currentTask: {
          ...prev.currentTask,
          steps: [...prev.currentTask.steps, newStep],
        },
      };
    });
  }, []);

  // Cancel the current task
  const cancelTask = useCallback(() => {
    setState(prev => {
      if (!prev.currentTask) return prev;

      // Stop screenshot capture
      if (screenshotIntervalRef.current) {
        clearInterval(screenshotIntervalRef.current);
        screenshotIntervalRef.current = null;
      }

      return {
        ...prev,
        currentTask: { ...prev.currentTask, status: 'cancelled' },
        isActive: false,
      };
    });
  }, []);

  // Simulate mouse click
  const simulateClick = async (x: number, y: number, button: 'left' | 'right' | 'middle' = 'left') => {
    const element = document.elementFromPoint(x, y);
    if (element) {
      const event = new MouseEvent('click', {
        bubbles: true,
        cancelable: true,
        clientX: x,
        clientY: y,
        button: button === 'left' ? 0 : button === 'middle' ? 1 : 2,
      });
      element.dispatchEvent(event);
    }
  };

  // Simulate double click
  const simulateDoubleClick = async (x: number, y: number) => {
    const element = document.elementFromPoint(x, y);
    if (element) {
      const event = new MouseEvent('dblclick', {
        bubbles: true,
        cancelable: true,
        clientX: x,
        clientY: y,
      });
      element.dispatchEvent(event);
    }
  };

  // Simulate mouse move
  const simulateMouseMove = async (x: number, y: number) => {
    const element = document.elementFromPoint(x, y);
    if (element) {
      const event = new MouseEvent('mousemove', {
        bubbles: true,
        cancelable: true,
        clientX: x,
        clientY: y,
      });
      element.dispatchEvent(event);
    }
  };

  // Simulate drag
  const simulateDrag = async (fromX: number, fromY: number, toX: number, toY: number) => {
    const element = document.elementFromPoint(fromX, fromY);
    if (element) {
      // Mouse down
      const downEvent = new MouseEvent('mousedown', {
        bubbles: true,
        cancelable: true,
        clientX: fromX,
        clientY: fromY,
      });
      element.dispatchEvent(downEvent);

      // Mouse move
      await new Promise(resolve => setTimeout(resolve, 50));
      const moveEvent = new MouseEvent('mousemove', {
        bubbles: true,
        cancelable: true,
        clientX: toX,
        clientY: toY,
      });
      document.dispatchEvent(moveEvent);

      // Mouse up
      await new Promise(resolve => setTimeout(resolve, 50));
      const upEvent = new MouseEvent('mouseup', {
        bubbles: true,
        cancelable: true,
        clientX: toX,
        clientY: toY,
      });
      document.dispatchEvent(upEvent);
    }
  };

  // Simulate scroll
  const simulateScroll = async (deltaX: number, deltaY: number) => {
    const element = document.elementFromPoint(window.innerWidth / 2, window.innerHeight / 2);
    if (element) {
      const event = new WheelEvent('wheel', {
        bubbles: true,
        cancelable: true,
        deltaX,
        deltaY,
      });
      element.dispatchEvent(event);
    }
  };

  // Simulate typing
  const simulateType = async (text: string) => {
    const activeElement = document.activeElement as HTMLElement;
    if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA')) {
      const input = activeElement as HTMLInputElement | HTMLTextAreaElement;
      input.value += text;
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
  };

  // Simulate key press
  const simulateKeyPress = async (key: string, modifiers?: string[]) => {
    const activeElement = document.activeElement;
    if (activeElement) {
      const event = new KeyboardEvent('keydown', {
        bubbles: true,
        cancelable: true,
        key,
        ctrlKey: modifiers?.includes('ctrl') || modifiers?.includes('Control'),
        shiftKey: modifiers?.includes('shift') || modifiers?.includes('Shift'),
        altKey: modifiers?.includes('alt') || modifiers?.includes('Alt'),
        metaKey: modifiers?.includes('meta') || modifiers?.includes('Meta'),
      });
      activeElement.dispatchEvent(event);

      // Key up
      await new Promise(resolve => setTimeout(resolve, 50));
      const upEvent = new KeyboardEvent('keyup', {
        bubbles: true,
        cancelable: true,
        key,
      });
      activeElement.dispatchEvent(upEvent);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (screenshotIntervalRef.current) {
        clearInterval(screenshotIntervalRef.current);
      }
    };
  }, []);

  return {
    ...state,
    captureScreenshot,
    executeAction,
    startTask,
    completeTask,
    cancelTask,
    addTaskStep,
  };
}

// Predefined action builders for common operations
export const ComputerActions = {
  screenshot: () => ({ type: 'screenshot' as const, params: {} }),
  click: (x: number, y: number, button: 'left' | 'right' | 'middle' = 'left') => ({
    type: 'click' as const,
    params: { x, y, button },
  }),
  doubleClick: (x: number, y: number) => ({
    type: 'double_click' as const,
    params: { x, y },
  }),
  move: (x: number, y: number) => ({
    type: 'move' as const,
    params: { x, y },
  }),
  drag: (fromX: number, fromY: number, toX: number, toY: number) => ({
    type: 'drag' as const,
    params: { fromX, fromY, toX, toY },
  }),
  scroll: (deltaX: number = 0, deltaY: number = 0) => ({
    type: 'scroll' as const,
    params: { deltaX, deltaY },
  }),
  type: (text: string) => ({
    type: 'type' as const,
    params: { text },
  }),
  keypress: (key: string, modifiers?: string[]) => ({
    type: 'keypress' as const,
    params: { key, modifiers },
  }),
  wait: (ms: number = 1000) => ({
    type: 'wait' as const,
    params: { ms },
  }),
  bash: (command: string) => ({
    type: 'bash' as const,
    params: { command },
  }),
};
