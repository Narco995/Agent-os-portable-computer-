import { useState, useCallback, useRef } from 'react';

interface TerminalSession {
  id: string;
  name: string;
  history: string[];
  currentPath: string;
}

// Command output type for future use
// interface CommandOutput {
//   command: string;
//   output: string;
//   error?: boolean;
// }

const INITIAL_SESSION: TerminalSession = {
  id: 'default',
  name: 'Terminal',
  history: [
    'Kimi OS Portable Terminal v2.0.0',
    'Type "help" for available commands.',
    '',
  ],
  currentPath: '/home/user',
};

const COMMANDS: Record<string, (args: string[], context: TerminalContext) => string> = {
  help: () => `Available commands:
  help              Show this help message
  clear             Clear the terminal
  ls [path]         List directory contents
  cd <path>         Change directory
  pwd               Print working directory
  cat <file>        Display file contents
  echo <text>       Print text
  mkdir <name>      Create directory
  touch <name>      Create empty file
  rm <name>         Remove file or directory
  cp <src> <dst>    Copy file
  mv <src> <dst>    Move/rename file
  grep <pattern>    Search for pattern
  ps                List processes
  top               Show system processes
  df                Show disk usage
  free              Show memory usage
  uname             Show system info
  whoami            Show current user
  date              Show current date/time
  calc <expr>       Calculate expression
  ai <prompt>       Send prompt to AI
  browser <url>     Open browser
  edit <file>       Open file in editor
  python            Start Python REPL
  exit              Close terminal`,

  clear: () => '__CLEAR__',

  ls: (_args, _ctx) => {
    // Simulated directory listing for current path
    const items = [
      { name: 'Documents', type: 'd', size: 4096, date: 'Mar 26 10:30' },
      { name: 'Downloads', type: 'd', size: 4096, date: 'Mar 26 09:15' },
      { name: 'Pictures', type: 'd', size: 4096, date: 'Mar 25 14:22' },
      { name: 'Projects', type: 'd', size: 4096, date: 'Mar 26 16:45' },
      { name: '.bashrc', type: '-', size: 2201, date: 'Mar 20 08:00' },
      { name: 'welcome.txt', type: '-', size: 312, date: 'Mar 26 12:00' },
    ];
    return items.map(i => 
      `${i.type === 'd' ? 'drwxr-xr-x' : '-rw-r--r--'} 1 user user ${i.size.toString().padStart(8)} ${i.date} ${i.name}`
    ).join('\n');
  },

  pwd: (_, ctx) => ctx.currentPath,

  cd: (args, ctx) => {
    if (!args[0] || args[0] === '~') {
      ctx.setPath('/home/user');
      return '';
    }
    ctx.setPath(args[0]);
    return '';
  },

  cat: (args) => {
    if (!args[0]) return 'cat: missing file operand';
    const files: Record<string, string> = {
      'welcome.txt': 'Welcome to Kimi OS Portable!\n\nThis is your personal portable computer.',
      '.bashrc': '# .bashrc\nexport PATH=$PATH:/usr/local/bin\nalias ll="ls -la"',
    };
    return files[args[0]] || `cat: ${args[0]}: No such file or directory`;
  },

  echo: (args) => args.join(' '),

  mkdir: (args) => {
    if (!args[0]) return 'mkdir: missing operand';
    return `Directory created: ${args[0]}`;
  },

  touch: (args) => {
    if (!args[0]) return 'touch: missing file operand';
    return `File created: ${args[0]}`;
  },

  rm: (args) => {
    if (!args[0]) return 'rm: missing operand';
    return `Removed: ${args[0]}`;
  },

  cp: (args) => {
    if (args.length < 2) return 'cp: missing destination file operand';
    return `Copied: ${args[0]} -> ${args[1]}`;
  },

  mv: (args) => {
    if (args.length < 2) return 'mv: missing destination file operand';
    return `Moved: ${args[0]} -> ${args[1]}`;
  },

  grep: (args) => {
    if (!args[0]) return 'grep: missing pattern';
    return `Searching for "${args[0]}"...\nFound 3 matches in 2 files`;
  },

  ps: () => `  PID TTY          TIME CMD\n    1 ?        00:00:01 systemd\n  234 ?        00:00:03 kimi-os\n  567 pts/0    00:00:00 bash\n  890 pts/0    00:00:00 terminal`,

  top: () => `Tasks: 45 total, 1 running, 44 sleeping
%Cpu(s): 12.3 us, 5.2 sy, 0.0 ni, 82.0 id
MiB Mem :  16384.0 total,   8192.0 free,   6144.0 used

  PID USER      PR  NI    VIRT    RES    SHR S  %CPU %MEM     TIME+ COMMAND
  234 user      20   0  234567  45678  12345 S   5.2  2.8   0:03.21 kimi-os
  567 user      20   0   12345   6789   2345 S   1.2  0.4   0:00.45 bash`,

  df: () => `Filesystem     1K-blocks     Used Available Use% Mounted on
/dev/sda1      512000000 180000000 332000000  35% /
tmpfs           8192000    512000   7680000   7% /tmp`,

  free: () => `              total        used        free      shared  buff/cache   available
Mem:       16384000     6144000     8192000      512000     2048000     9248000
Swap:       4096000           0     4096000`,

  uname: (args) => {
    const flags = args.join('');
    if (flags.includes('-a')) {
      return 'Linux kimi-os 6.8.0-kimi #1 SMP Kimi OS Portable x86_64 GNU/Linux';
    }
    return 'Kimi OS';
  },

  whoami: () => 'user',

  date: () => new Date().toString(),

  calc: (args) => {
    try {
      const expr = args.join(' ');
      // Safe evaluation - only allow basic math
      const sanitized = expr.replace(/[^0-9+\-*/().\s]/g, '');
      const result = Function(`"use strict"; return (${sanitized})`)();
      return result.toString();
    } catch (e) {
      return 'calc: invalid expression';
    }
  },

  ai: (args) => {
    if (!args.length) return 'ai: missing prompt';
    const prompt = args.join(' ');
    return `AI Response to "${prompt}":\n\nI'm your AI assistant. I can help you with tasks, answer questions, and control this portable computer system.`;
  },

  browser: (args) => {
    if (!args[0]) return 'browser: missing URL';
    return `Opening browser: ${args[0]}\n(Use the Browser app for full web browsing)`;
  },

  edit: (args) => {
    if (!args[0]) return 'edit: missing file operand';
    return `Opening editor: ${args[0]}\n(Use the Editor app for full editing)`;
  },

  python: () => `Python 3.11.0 (default, Mar 26 2024, 12:00:00)
Type "help", "copyright", "credits" or "license" for more information.
>>> `,

  exit: () => '__EXIT__',
};

interface TerminalContext {
  currentPath: string;
  setPath: (path: string) => void;
}

export function useTerminal() {
  const [sessions, setSessions] = useState<TerminalSession[]>([INITIAL_SESSION]);
  const [activeSessionId, setActiveSessionId] = useState<string>('default');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const historyIndexRef = useRef(-1);

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0];

  const executeCommand = useCallback((input: string): string => {
    const trimmed = input.trim();
    if (!trimmed) return '';

    setCommandHistory(prev => [...prev, trimmed]);
    historyIndexRef.current = -1;

    const parts = trimmed.split(' ');
    const command = parts[0];
    const args = parts.slice(1);

    const context: TerminalContext = {
      currentPath: activeSession.currentPath,
      setPath: (path) => {
        setSessions(prev => prev.map(s => 
          s.id === activeSessionId ? { ...s, currentPath: path } : s
        ));
      },
    };

    const handler = COMMANDS[command];
    if (handler) {
      return handler(args, context);
    }

    return `${command}: command not found`;
  }, [activeSession, activeSessionId]);

  const addOutput = useCallback((text: string) => {
    setSessions(prev => prev.map(s => 
      s.id === activeSessionId 
        ? { ...s, history: [...s.history, text] }
        : s
    ));
  }, [activeSessionId]);

  const clearHistory = useCallback(() => {
    setSessions(prev => prev.map(s => 
      s.id === activeSessionId 
        ? { ...s, history: [] }
        : s
    ));
  }, [activeSessionId]);

  const createSession = useCallback((name?: string) => {
    const id = `session-${Date.now()}`;
    const newSession: TerminalSession = {
      id,
      name: name || `Terminal ${sessions.length + 1}`,
      history: [],
      currentPath: '/home/user',
    };
    setSessions(prev => [...prev, newSession]);
    setActiveSessionId(id);
    return id;
  }, [sessions.length]);

  const closeSession = useCallback((id: string) => {
    setSessions(prev => {
      const filtered = prev.filter(s => s.id !== id);
      if (filtered.length === 0) {
        filtered.push(INITIAL_SESSION);
      }
      return filtered;
    });
    if (activeSessionId === id) {
      const remaining = sessions.filter(s => s.id !== id);
      setActiveSessionId(remaining[0]?.id || 'default');
    }
  }, [activeSessionId, sessions]);

  const getPreviousCommand = useCallback(() => {
    if (commandHistory.length === 0) return '';
    historyIndexRef.current = Math.min(
      historyIndexRef.current + 1,
      commandHistory.length - 1
    );
    return commandHistory[commandHistory.length - 1 - historyIndexRef.current];
  }, [commandHistory]);

  const getNextCommand = useCallback(() => {
    if (historyIndexRef.current <= 0) {
      historyIndexRef.current = -1;
      return '';
    }
    historyIndexRef.current--;
    return commandHistory[commandHistory.length - 1 - historyIndexRef.current];
  }, [commandHistory]);

  return {
    sessions,
    activeSession,
    activeSessionId,
    setActiveSessionId,
    executeCommand,
    addOutput,
    clearHistory,
    createSession,
    closeSession,
    getPreviousCommand,
    getNextCommand,
  };
}
