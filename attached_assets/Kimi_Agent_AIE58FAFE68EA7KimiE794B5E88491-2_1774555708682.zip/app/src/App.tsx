import { useState, useCallback, useEffect, useRef } from 'react';
import { Desktop } from '@/sections/Desktop';
import { Taskbar } from '@/sections/Taskbar';
import { WindowManager } from '@/sections/WindowManager';
import { AIControlPanel } from '@/sections/AIControlPanel';
import { ComputerUsePanel } from '@/sections/ComputerUsePanel';
import { useWindowManager } from '@/hooks/useWindowManager';
import { useAIAgentControl } from '@/hooks/useAIAgentControl';
import { useComputerUse, ComputerActions } from '@/hooks/useComputerUse';
import { useHardwareMonitor } from '@/hooks/useHardwareMonitor';
import { useFileSystem } from '@/hooks/useFileSystem';
import { useTerminal } from '@/hooks/useTerminal';
import type { AIControlCommand, AppType } from '@/types/system';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';
import html2canvas from 'html2canvas';

function App() {
  const [showAIControl, setShowAIControl] = useState(false);
  const [showComputerUse, setShowComputerUse] = useState(false);
  const [systemTime, setSystemTime] = useState(new Date());
  const [isBooting, setIsBooting] = useState(true);
  const [bootProgress, setBootProgress] = useState(0);
  const desktopRef = useRef<HTMLDivElement>(null);

  const windowManager = useWindowManager();
  const hardware = useHardwareMonitor();
  const fileSystem = useFileSystem();
  const terminal = useTerminal();

  // Computer-Use hook for agent control
  const computerUse = useComputerUse({
    onAction: (action) => {
      console.log('Computer action:', action);
    },
    onObservation: (observation) => {
      console.log('Computer observation:', observation);
    },
    onTaskComplete: (task) => {
      toast.success(`Task completed: ${task.description}`);
    },
    onError: (error) => {
      toast.error(`Computer-use error: ${error.message}`);
    },
  });

  // Handle AI command execution
  const handleAICommand = useCallback(async (command: AIControlCommand): Promise<any> => {
    console.log('Executing AI command:', command);
    
    switch (command.type) {
      case 'computer-use':
        return handleComputerUseCommand(command.action, command.params);
      case 'window':
        return handleWindowCommand(command.action, command.params);
      case 'system':
        return handleSystemCommand(command.action, command.params);
      case 'file':
        return handleFileCommand(command.action, command.params);
      case 'browser':
        return handleBrowserCommand(command.action, command.params);
      case 'mouse':
      case 'keyboard':
        return { simulated: true, type: command.type, action: command.action };
      default:
        throw new Error(`Unknown command type: ${command.type}`);
    }
  }, [windowManager, fileSystem, hardware, computerUse]);

  const aiControl = useAIAgentControl({
    onExecuteCommand: handleAICommand,
    onAgentConnect: (agent) => {
      toast.success(`Agent connected: ${agent.name}`);
    },
    onAgentDisconnect: (agentId) => {
      toast.info(`Agent disconnected: ${agentId}`);
    },
    onTaskCreated: (task) => {
      toast.info(`Task created: ${task.description}`);
    },
    onTaskComplete: (task) => {
      toast.success(`Task completed: ${task.description}`);
    },
  });

  // Handle computer-use commands
  const handleComputerUseCommand = async (action: string, params: any) => {
    switch (action) {
      case 'screenshot':
        if (desktopRef.current) {
          const canvas = await html2canvas(desktopRef.current, { scale: 0.5 });
          return { screenshot: canvas.toDataURL('image/jpeg', 0.8) };
        }
        return { screenshot: null };
      case 'click':
        await computerUse.executeAction(ComputerActions.click(params.x, params.y));
        return { clicked: true, x: params.x, y: params.y };
      case 'doubleClick':
        await computerUse.executeAction(ComputerActions.doubleClick(params.x, params.y));
        return { doubleClicked: true, x: params.x, y: params.y };
      case 'type':
        await computerUse.executeAction(ComputerActions.type(params.text));
        return { typed: true, text: params.text };
      case 'keypress':
        await computerUse.executeAction(ComputerActions.keypress(params.key, params.modifiers));
        return { keyPressed: true, key: params.key };
      case 'scroll':
        await computerUse.executeAction(ComputerActions.scroll(params.deltaX, params.deltaY));
        return { scrolled: true, deltaX: params.deltaX, deltaY: params.deltaY };
      case 'wait':
        await computerUse.executeAction(ComputerActions.wait(params.ms));
        return { waited: true, ms: params.ms };
      default:
        throw new Error(`Unknown computer-use action: ${action}`);
    }
  };

  // Window command handler
  const handleWindowCommand = (action: string, params: any) => {
    switch (action) {
      case 'open':
        return windowManager.openWindow(params.appType as AppType, params.title);
      case 'close':
        windowManager.closeWindow(params.windowId);
        return { closed: params.windowId };
      case 'focus':
        windowManager.focusWindow(params.windowId);
        return { focused: params.windowId };
      case 'move':
        windowManager.updateWindowPosition(params.windowId, params.x, params.y);
        return { moved: params.windowId, x: params.x, y: params.y };
      case 'resize':
        windowManager.updateWindowSize(params.windowId, params.width, params.height);
        return { resized: params.windowId, width: params.width, height: params.height };
      case 'minimize':
        windowManager.minimizeWindow(params.windowId);
        return { minimized: params.windowId };
      case 'maximize':
        windowManager.maximizeWindow(params.windowId);
        return { maximized: params.windowId };
      default:
        throw new Error(`Unknown window action: ${action}`);
    }
  };

  // System command handler
  const handleSystemCommand = (action: string, params: any) => {
    switch (action) {
      case 'screenshot':
        return { screenshot: 'data:image/png;base64,...' };
      case 'getStats':
        return hardware.stats;
      case 'setComputeMode':
        hardware.setComputeMode(params.mode);
        return { mode: params.mode };
      case 'execute':
        const result = terminal.executeCommand(params.command);
        return { output: result };
      default:
        throw new Error(`Unknown system action: ${action}`);
    }
  };

  // File command handler
  const handleFileCommand = (action: string, params: any) => {
    switch (action) {
      case 'read':
        const file = fileSystem.readFile(params.path);
        return { content: file?.content };
      case 'write':
        return { written: params.path };
      case 'list':
        return { items: fileSystem.getCurrentFolderContents() };
      case 'createFolder':
        return { created: fileSystem.createFolder(params.path) };
      default:
        throw new Error(`Unknown file action: ${action}`);
    }
  };

  // Browser command handler
  const handleBrowserCommand = (action: string, params: any) => {
    switch (action) {
      case 'navigate':
        return { navigated: params.url };
      case 'search':
        return { searched: params.query };
      default:
        throw new Error(`Unknown browser action: ${action}`);
    }
  };

  // Update system time
  useEffect(() => {
    const interval = setInterval(() => setSystemTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  // Boot sequence with progress
  useEffect(() => {
    const progressInterval = setInterval(() => {
      setBootProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 200);

    const bootTimeout = setTimeout(() => {
      setIsBooting(false);
      toast.success('Kimi OS Portable Ready', {
        description: 'Your AI-controllable portable computer is ready to use.',
      });
      
      // Start AI control listening
      aiControl.startListening(7777);
    }, 3000);

    return () => {
      clearInterval(progressInterval);
      clearTimeout(bootTimeout);
    };
  }, [aiControl]);

  // Handle app launch from desktop
  const handleAppLaunch = useCallback((appType: AppType) => {
    windowManager.openWindow(appType);
  }, [windowManager]);

  if (isBooting) {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center text-green-500 font-mono z-[9999]">
        <div className="w-full max-w-2xl p-8">
          <div className="mb-4 text-2xl font-bold">Kimi OS Portable</div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <span className="w-4">[</span>
              <span className="text-green-400">OK</span>
              <span className="w-4">]</span>
              <span>Initializing kernel...</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4">[</span>
              <span className="text-green-400">OK</span>
              <span className="w-4">]</span>
              <span>Loading hardware drivers...</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4">[</span>
              <span className="text-green-400">OK</span>
              <span className="w-4">]</span>
              <span>Mounting file systems...</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4">[</span>
              <span className="text-green-400">OK</span>
              <span className="w-4">]</span>
              <span>Starting AI agent control service...</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4">[</span>
              <span className="text-green-400">OK</span>
              <span className="w-4">]</span>
              <span>Initializing computer-use capabilities...</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4">[</span>
              <span className="text-green-400">OK</span>
              <span className="w-4">]</span>
              <span>Loading window manager...</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4">[</span>
              <span className="text-green-400">OK</span>
              <span className="w-4">]</span>
              <span>Loading applications...</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4">[</span>
              <span className="text-green-400">OK</span>
              <span className="w-4">]</span>
              <span>Starting hardware monitoring...</span>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-8">
            <div className="flex items-center justify-between text-xs mb-1">
              <span>Booting...</span>
              <span>{Math.min(100, Math.round(bootProgress))}%</span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-green-500 transition-all duration-200"
                style={{ width: `${Math.min(100, bootProgress)}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={desktopRef}
      id="kimi-os-desktop"
      className="fixed inset-0 overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"
    >
      {/* Desktop Background */}
      <div 
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: `
            radial-gradient(circle at 20% 80%, rgba(59, 130, 246, 0.15) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(139, 92, 246, 0.15) 0%, transparent 50%),
            radial-gradient(circle at 50% 50%, rgba(16, 185, 129, 0.05) 0%, transparent 50%)
          `,
        }}
      />

      {/* Desktop Icons */}
      <Desktop onAppLaunch={handleAppLaunch} />

      {/* Window Manager */}
      <WindowManager
        windows={windowManager.windows}
        focusedWindowId={windowManager.focusedWindowId}
        onFocus={windowManager.focusWindow}
        onClose={windowManager.closeWindow}
        onMinimize={windowManager.minimizeWindow}
        onMaximize={windowManager.maximizeWindow}
        onRestore={windowManager.restoreWindow}
        onUpdatePosition={windowManager.updateWindowPosition}
        onUpdateSize={windowManager.updateWindowSize}
        onUpdateTitle={windowManager.updateWindowTitle}
        hardware={hardware}
        fileSystem={fileSystem}
        terminal={terminal}
        aiControl={aiControl}
      />

      {/* Taskbar */}
      <Taskbar
        windows={windowManager.windows}
        activeWindowId={windowManager.focusedWindowId}
        onWindowClick={(id) => {
          const win = windowManager.getWindowById(id);
          if (win?.isMinimized) {
            windowManager.restoreWindow(id);
          } else if (win?.isFocused) {
            windowManager.minimizeWindow(id);
          } else {
            windowManager.focusWindow(id);
          }
        }}
        onAppLaunch={handleAppLaunch}
        onAIPanelToggle={() => setShowAIControl(!showAIControl)}
        onComputerUseToggle={() => setShowComputerUse(!showComputerUse)}
        systemTime={systemTime}
        hardware={hardware}
        aiControl={aiControl}
        computerUse={computerUse}
      />

      {/* AI Control Panel */}
      {showAIControl && (
        <AIControlPanel
          aiControl={aiControl}
          onClose={() => setShowAIControl(false)}
          onExecuteCommand={handleAICommand}
        />
      )}

      {/* Computer-Use Panel */}
      {showComputerUse && (
        <ComputerUsePanel
          computerUse={computerUse}
          onClose={() => setShowComputerUse(false)}
        />
      )}

      <Toaster />
    </div>
  );
}

export default App;
