// Kimi OS Portable - Enhanced System Types
// Inspired by AIOS, E2B, Agent Zero, Manus, OpenAI CUA, Claude Computer Use

export interface Window {
  id: string;
  title: string;
  appType: AppType;
  x: number;
  y: number;
  width: number;
  height: number;
  isMinimized: boolean;
  isMaximized: boolean;
  isFocused: boolean;
  zIndex: number;
  content?: any;
}

export type AppType = 
  | 'terminal'
  | 'files'
  | 'browser'
  | 'editor'
  | 'settings'
  | 'aichat'
  | 'python'
  | 'hardware'
  | 'airouter'
  | 'desktop'
  | 'vnc';

export interface Application {
  id: AppType;
  name: string;
  icon: string;
  description: string;
  defaultWidth: number;
  defaultHeight: number;
  canMultipleInstances: boolean;
}

export interface FileSystemItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  parentId: string | null;
  content?: string;
  size?: number;
  createdAt: Date;
  modifiedAt: Date;
  isOpen?: boolean;
}

export interface HardwareStats {
  cpu: {
    usage: number;
    cores: number;
    frequency: number;
    temperature: number;
  };
  memory: {
    used: number;
    total: number;
    percentage: number;
  };
  gpu?: {
    usage: number;
    memory: number;
    temperature: number;
  };
  network: {
    status: 'online' | 'offline';
    downloadSpeed: number;
    uploadSpeed: number;
  };
  storage: {
    used: number;
    total: number;
  };
}

export type ComputeMode = 'local' | 'hybrid' | 'cloud';

// Enhanced AI Agent Types
export interface AIAgent {
  id: string;
  name: string;
  type: 'local' | 'external' | 'system';
  status: 'idle' | 'busy' | 'error' | 'offline';
  capabilities: AgentCapability[];
  endpoint?: string;
  apiKey?: string;
  metadata?: Record<string, any>;
  lastSeen?: Date;
}

export type AgentCapability = 
  | 'computer-use'
  | 'browser'
  | 'terminal'
  | 'files'
  | 'code'
  | 'vision'
  | 'chat'
  | 'system'
  | 'planning'
  | 'memory';

// Computer-Use Agent Action Types (inspired by OpenAI CUA and Claude Computer Use)
export interface ComputerAction {
  id: string;
  type: 'screenshot' | 'click' | 'double_click' | 'move' | 'drag' | 'scroll' | 'type' | 'keypress' | 'wait' | 'bash';
  params: any;
  timestamp: Date;
  agentId?: string;
}

export interface ComputerObservation {
  screenshot?: string; // base64 encoded
  text?: string;
  html?: string;
  url?: string;
  timestamp: Date;
}

export interface AIControlCommand {
  id: string;
  type: 'mouse' | 'keyboard' | 'window' | 'system' | 'file' | 'browser' | 'computer-use' | 'agent';
  action: string;
  params: any;
  timestamp: Date;
  agentId: string;
  callbackUrl?: string;
}

// Agent Task Types (inspired by AIOS)
export interface AgentTask {
  id: string;
  agentId: string;
  type: 'computer-use' | 'browser' | 'terminal' | 'code' | 'file' | 'planning';
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  description: string;
  steps: TaskStep[];
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  result?: any;
  error?: string;
}

export interface TaskStep {
  id: string;
  type: 'action' | 'observation' | 'thought' | 'tool';
  content: string;
  data?: any;
  timestamp: Date;
}

// Session Types (inspired by E2B)
export interface AgentSession {
  id: string;
  agentId: string;
  status: 'active' | 'paused' | 'closed';
  createdAt: Date;
  lastActivityAt: Date;
  context: Record<string, any>;
  history: SessionEvent[];
}

export interface SessionEvent {
  id: string;
  type: 'command' | 'action' | 'observation' | 'message';
  data: any;
  timestamp: Date;
}

export interface TerminalSession {
  id: string;
  name: string;
  history: string[];
  currentPath: string;
}

export interface BrowserTab {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  isLoading: boolean;
}

export interface EditorFile {
  id: string;
  name: string;
  content: string;
  language: string;
  isModified: boolean;
  path: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  agentId?: string;
  attachments?: Attachment[];
}

export interface Attachment {
  id: string;
  type: 'image' | 'file' | 'code';
  name: string;
  content: string;
}

export interface SystemSettings {
  theme: 'dark' | 'light' | 'auto';
  accentColor: string;
  transparency: boolean;
  animations: boolean;
  notifications: boolean;
  autoSave: boolean;
  computeMode: ComputeMode;
  defaultBrowser: string;
  terminalShell: string;
  agentApiPort: number;
  allowExternalAgents: boolean;
  requireApiKey: boolean;
  sessionTimeout: number;
}

// API Types
export interface ExternalAIRequest {
  agentId: string;
  action: string;
  params: any;
  callbackUrl?: string;
}

export interface ExternalAIResponse {
  success: boolean;
  data?: any;
  error?: string;
  timestamp: Date;
}

// Computer-Use API Types (inspired by OpenAI CUA)
export interface ComputerUseRequest {
  model?: string;
  messages: ComputerUseMessage[];
  tools?: ComputerUseTool[];
  max_iterations?: number;
}

export interface ComputerUseMessage {
  role: 'user' | 'assistant' | 'system';
  content: string | ComputerUseContent[];
}

export interface ComputerUseContent {
  type: 'text' | 'image_url';
  text?: string;
  image_url?: { url: string };
}

export interface ComputerUseTool {
  type: 'computer_use_preview';
  display_width?: number;
  display_height?: number;
  environment?: 'browser' | 'desktop';
}

export interface ComputerUseResponse {
  id: string;
  output: ComputerUseOutput[];
  usage?: {
    input_tokens: number;
    output_tokens: number;
  };
}

export interface ComputerUseOutput {
  type: 'message' | 'computer_call' | 'computer_call_output';
  content?: ComputerUseContent[];
  call_id?: string;
  action?: ComputerAction;
  acknowledged_safety_checks?: string[];
  safety_checks?: SafetyCheck[];
}

export interface SafetyCheck {
  id: string;
  code: string;
  message: string;
}
