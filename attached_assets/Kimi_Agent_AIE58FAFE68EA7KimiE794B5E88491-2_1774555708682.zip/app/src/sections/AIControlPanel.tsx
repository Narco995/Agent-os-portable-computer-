import { useState } from 'react';
import { useAIAgentControl } from '@/hooks/useAIAgentControl';
import type { AIControlCommand } from '@/types/system';
import {
  X,
  Bot,
  Play,
  Pause,
  Plus,
  Trash2,
  Terminal,
  MousePointer,
  Keyboard,
  Folder,
  Globe,
  Settings,
  Send,
  CheckCircle,
  AlertCircle,
  Clock,
  ChevronDown,
  ChevronRight,
  Copy,
  Check,
} from 'lucide-react';
import { toast } from 'sonner';

interface AIControlPanelProps {
  aiControl: ReturnType<typeof useAIAgentControl>;
  onClose: () => void;
  onExecuteCommand: (command: AIControlCommand) => Promise<any>;
}

export function AIControlPanel({ aiControl, onClose, onExecuteCommand }: AIControlPanelProps) {
  const [activeTab, setActiveTab] = useState<'agents' | 'commands' | 'console'>('agents');
  const [newAgentName, setNewAgentName] = useState('');
  const [newAgentEndpoint, setNewAgentEndpoint] = useState('');
  const [newAgentApiKey, setNewAgentApiKey] = useState('');
  const [selectedCommandType, setSelectedCommandType] = useState<string>('window');
  const [commandParams, setCommandParams] = useState<Record<string, any>>({});
  const [consoleInput, setConsoleInput] = useState('');
  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);
  const [expandedCommands, setExpandedCommands] = useState<Set<string>>(new Set());
  const [copiedEndpoint, setCopiedEndpoint] = useState(false);

  const { agents, isListening, pendingCommands, commandHistory, registerAgent, unregisterAgent, startListening, stopListening } = aiControl;

  const toggleCommandExpand = (cmdId: string) => {
    setExpandedCommands(prev => {
      const newSet = new Set(prev);
      if (newSet.has(cmdId)) {
        newSet.delete(cmdId);
      } else {
        newSet.add(cmdId);
      }
      return newSet;
    });
  };

  const handleRegisterAgent = () => {
    if (!newAgentName) return;
    
    registerAgent({
      name: newAgentName,
      type: 'external',
      status: 'idle',
      capabilities: ['computer-use', 'browser', 'files'],
      endpoint: newAgentEndpoint || undefined,
      apiKey: newAgentApiKey || undefined,
    });
    
    setNewAgentName('');
    setNewAgentEndpoint('');
    setNewAgentApiKey('');
    toast.success('Agent registered successfully');
  };

  const handleExecuteCommand = async () => {
    try {
      const command: AIControlCommand = {
        id: `manual-${Date.now()}`,
        type: selectedCommandType as any,
        action: commandParams.action || 'open',
        params: commandParams,
        timestamp: new Date(),
        agentId: 'manual',
      };
      
      const result = await onExecuteCommand(command);
      setConsoleOutput(prev => [...prev, `> ${JSON.stringify(command)}`, JSON.stringify(result, null, 2)]);
      toast.success('Command executed');
    } catch (error) {
      toast.error('Command failed');
    }
  };

  const handleConsoleSubmit = async () => {
    if (!consoleInput.trim()) return;
    
    setConsoleOutput(prev => [...prev, `> ${consoleInput}`]);
    
    try {
      // Parse natural language command
      const response = await fetch('/api/ai/parse-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: consoleInput }),
      });
      
      if (response.ok) {
        const { command } = await response.json();
        const result = await onExecuteCommand(command);
        setConsoleOutput(prev => [...prev, JSON.stringify(result, null, 2)]);
      } else {
        setConsoleOutput(prev => [...prev, 'Error: Could not parse command']);
      }
    } catch (e) {
      setConsoleOutput(prev => [...prev, 'Error: ' + (e as Error).message]);
    }
    
    setConsoleInput('');
  };

  const copyEndpoint = () => {
    navigator.clipboard.writeText('ws://localhost:7777/ai-events');
    setCopiedEndpoint(true);
    setTimeout(() => setCopiedEndpoint(false), 2000);
  };

  const commandTypes = [
    { id: 'window', icon: <Terminal className="w-4 h-4" />, label: 'Window' },
    { id: 'mouse', icon: <MousePointer className="w-4 h-4" />, label: 'Mouse' },
    { id: 'keyboard', icon: <Keyboard className="w-4 h-4" />, label: 'Keyboard' },
    { id: 'file', icon: <Folder className="w-4 h-4" />, label: 'File' },
    { id: 'browser', icon: <Globe className="w-4 h-4" />, label: 'Browser' },
    { id: 'system', icon: <Settings className="w-4 h-4" />, label: 'System' },
  ];

  return (
    <div className="fixed top-16 right-4 w-[480px] max-h-[80vh] bg-slate-900/98 backdrop-blur-xl rounded-xl border border-white/10 shadow-2xl overflow-hidden z-[1000] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5 text-blue-400" />
          <span className="font-semibold text-white/90">AI Control Panel</span>
          <div className={`w-2 h-2 rounded-full ${isListening ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
        </div>
        <button onClick={onClose} className="p-1 rounded-lg hover:bg-white/10 transition-all">
          <X className="w-4 h-4 text-white/70" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10">
        {(['agents', 'commands', 'console'] as const).map((tab) => (
          <button
            key={tab}
            className={`flex-1 px-4 py-2 text-sm font-medium transition-all ${
              activeTab === tab
                ? 'text-blue-400 border-b-2 border-blue-400 bg-blue-500/10'
                : 'text-white/60 hover:text-white/90 hover:bg-white/5'
            }`}
            onClick={() => setActiveTab(tab)}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        {activeTab === 'agents' && (
          <div className="space-y-4">
            {/* Connection Status */}
            <div className="p-3 bg-white/5 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-white/70">Control API Endpoint</span>
                <button
                  onClick={copyEndpoint}
                  className="p-1 rounded hover:bg-white/10 transition-all"
                >
                  {copiedEndpoint ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-white/50" />}
                </button>
              </div>
              <code className="text-xs text-blue-400 bg-blue-500/10 px-2 py-1 rounded block">
                ws://localhost:7777/ai-events
              </code>
              <div className="flex items-center gap-2 mt-2">
                <button
                  onClick={() => {
                    if (isListening) {
                      stopListening();
                    } else {
                      startListening(7777);
                    }
                  }}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    isListening
                      ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                      : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                  }`}
                >
                  {isListening ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  {isListening ? 'Stop Listening' : 'Start Listening'}
                </button>
              </div>
            </div>

            {/* Registered Agents */}
            <div>
              <div className="text-sm font-medium text-white/70 mb-2">Registered Agents ({agents.length})</div>
              <div className="space-y-2">
                {agents.map((agent) => (
                  <div key={agent.id} className="p-3 bg-white/5 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${
                        agent.status === 'idle' ? 'bg-green-400' :
                        agent.status === 'busy' ? 'bg-yellow-400' : 'bg-red-400'
                      }`} />
                      <div>
                        <div className="text-sm text-white/90">{agent.name}</div>
                        <div className="text-xs text-white/50">{agent.type} • {agent.status}</div>
                      </div>
                    </div>
                    {agent.type === 'external' && (
                      <button
                        onClick={() => unregisterAgent(agent.id)}
                        className="p-1.5 rounded-lg hover:bg-red-500/20 text-white/50 hover:text-red-400 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Add Agent */}
            <div className="p-3 bg-white/5 rounded-lg space-y-2">
              <div className="text-sm font-medium text-white/70">Register External Agent</div>
              <input
                type="text"
                placeholder="Agent name"
                value={newAgentName}
                onChange={(e) => setNewAgentName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90 placeholder:text-white/30 focus:outline-none focus:border-blue-500"
              />
              <input
                type="text"
                placeholder="Endpoint URL (optional)"
                value={newAgentEndpoint}
                onChange={(e) => setNewAgentEndpoint(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90 placeholder:text-white/30 focus:outline-none focus:border-blue-500"
              />
              <input
                type="password"
                placeholder="API Key (optional)"
                value={newAgentApiKey}
                onChange={(e) => setNewAgentApiKey(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90 placeholder:text-white/30 focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={handleRegisterAgent}
                disabled={!newAgentName}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-blue-500/20 text-blue-400 rounded-lg text-sm font-medium hover:bg-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                <Plus className="w-4 h-4" />
                Register Agent
              </button>
            </div>
          </div>
        )}

        {activeTab === 'commands' && (
          <div className="space-y-4">
            {/* Command Types */}
            <div className="flex flex-wrap gap-2">
              {commandTypes.map((type) => (
                <button
                  key={type.id}
                  onClick={() => setSelectedCommandType(type.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-all ${
                    selectedCommandType === type.id
                      ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                      : 'bg-white/5 text-white/70 hover:bg-white/10'
                  }`}
                >
                  {type.icon}
                  {type.label}
                </button>
              ))}
            </div>

            {/* Command Builder */}
            <div className="p-3 bg-white/5 rounded-lg space-y-3">
              <div className="text-sm font-medium text-white/70">Build Command</div>
              
              {selectedCommandType === 'window' && (
                <>
                  <select
                    onChange={(e) => setCommandParams({ ...commandParams, action: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90"
                  >
                    <option value="open">Open Window</option>
                    <option value="close">Close Window</option>
                    <option value="focus">Focus Window</option>
                    <option value="minimize">Minimize</option>
                    <option value="maximize">Maximize</option>
                  </select>
                  <input
                    type="text"
                    placeholder="App type (terminal, browser, etc.)"
                    onChange={(e) => setCommandParams({ ...commandParams, appType: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90 placeholder:text-white/30"
                  />
                </>
              )}

              {selectedCommandType === 'browser' && (
                <>
                  <select
                    onChange={(e) => setCommandParams({ ...commandParams, action: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90"
                  >
                    <option value="navigate">Navigate</option>
                    <option value="search">Search</option>
                    <option value="getContent">Get Content</option>
                  </select>
                  <input
                    type="text"
                    placeholder="URL or query"
                    onChange={(e) => setCommandParams({ ...commandParams, url: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90 placeholder:text-white/30"
                  />
                </>
              )}

              {selectedCommandType === 'system' && (
                <>
                  <select
                    onChange={(e) => setCommandParams({ ...commandParams, action: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90"
                  >
                    <option value="getStats">Get System Stats</option>
                    <option value="screenshot">Take Screenshot</option>
                    <option value="setComputeMode">Set Compute Mode</option>
                  </select>
                </>
              )}

              <button
                onClick={handleExecuteCommand}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-green-500/20 text-green-400 rounded-lg text-sm font-medium hover:bg-green-500/30 transition-all"
              >
                <Send className="w-4 h-4" />
                Execute Command
              </button>
            </div>

            {/* Pending Commands */}
            {pendingCommands.length > 0 && (
              <div>
                <div className="text-sm font-medium text-white/70 mb-2">
                  Pending ({pendingCommands.length})
                </div>
                <div className="space-y-1">
                  {pendingCommands.map((cmd) => (
                    <div key={cmd.id} className="p-2 bg-yellow-500/10 rounded-lg flex items-center gap-2">
                      <Clock className="w-4 h-4 text-yellow-400" />
                      <span className="text-xs text-white/70">{cmd.type}.{cmd.action}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Command History */}
            {commandHistory.length > 0 && (
              <div>
                <div className="text-sm font-medium text-white/70 mb-2">History</div>
                <div className="space-y-1 max-h-40 overflow-auto">
                  {commandHistory.slice(-10).map((cmd) => (
                    <div
                      key={cmd.id}
                      className="p-2 bg-white/5 rounded-lg cursor-pointer hover:bg-white/10"
                      onClick={() => toggleCommandExpand(cmd.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {'error' in cmd ? (
                            <AlertCircle className="w-4 h-4 text-red-400" />
                          ) : (
                            <CheckCircle className="w-4 h-4 text-green-400" />
                          )}
                          <span className="text-xs text-white/70">{cmd.type}.{cmd.action}</span>
                        </div>
                        {expandedCommands.has(cmd.id) ? (
                          <ChevronDown className="w-3 h-3 text-white/50" />
                        ) : (
                          <ChevronRight className="w-3 h-3 text-white/50" />
                        )}
                      </div>
                      {expandedCommands.has(cmd.id) && (
                        <pre className="mt-2 text-xs text-white/50 overflow-auto">
                          {JSON.stringify(cmd, null, 2)}
                        </pre>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'console' && (
          <div className="space-y-4">
            {/* Console Output */}
            <div className="bg-slate-950 rounded-lg p-3 font-mono text-sm h-64 overflow-auto">
              {consoleOutput.length === 0 ? (
                <div className="text-white/30 italic">Enter commands to interact with the system...</div>
              ) : (
                consoleOutput.map((line, i) => (
                  <div
                    key={i}
                    className={`${
                      line.startsWith('>') ? 'text-blue-400' : 'text-white/70'
                    } ${line.startsWith('Error') ? 'text-red-400' : ''}`}
                  >
                    {line}
                  </div>
                ))
              )}
            </div>

            {/* Console Input */}
            <div className="flex gap-2">
              <input
                type="text"
                value={consoleInput}
                onChange={(e) => setConsoleInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleConsoleSubmit()}
                placeholder="Enter natural language command..."
                className="flex-1 px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90 placeholder:text-white/30 focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={handleConsoleSubmit}
                className="px-3 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-all"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Commands */}
            <div>
              <div className="text-sm font-medium text-white/70 mb-2">Quick Commands</div>
              <div className="flex flex-wrap gap-2">
                {[
                  'Open terminal',
                  'Open browser to google.com',
                  'Show system stats',
                  'List files',
                  'Open editor',
                ].map((cmd) => (
                  <button
                    key={cmd}
                    onClick={() => {
                      setConsoleInput(cmd);
                      handleConsoleSubmit();
                    }}
                    className="px-3 py-1.5 bg-white/5 text-white/70 rounded-lg text-xs hover:bg-white/10 transition-all"
                  >
                    {cmd}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
