import { useEffect, useState } from 'react';
import type { Window } from '@/types/system';
import { useHardwareMonitor } from '@/hooks/useHardwareMonitor';
import { useFileSystem } from '@/hooks/useFileSystem';
import { useTerminal } from '@/hooks/useTerminal';
import { useAIAgentControl } from '@/hooks/useAIAgentControl';
import { TerminalWindow } from '@/components/windows/TerminalWindow';
import { FileManagerWindow } from '@/components/windows/FileManagerWindow';
import { BrowserWindow } from '@/components/windows/BrowserWindow';
import { EditorWindow } from '@/components/windows/EditorWindow';
import { SettingsWindow } from '@/components/windows/SettingsWindow';
import { AIChatWindow } from '@/components/windows/AIChatWindow';
import { PythonWindow } from '@/components/windows/PythonWindow';
import { HardwareWindow } from '@/components/windows/HardwareWindow';
import { AIRouterWindow } from '@/components/windows/AIRouterWindow';
import { 
  X, 
  Minus, 
  Maximize2, 
  Minimize2,
  GripVertical 
} from 'lucide-react';

interface WindowManagerProps {
  windows: Window[];
  focusedWindowId: string | null;
  onFocus: (id: string) => void;
  onClose: (id: string) => void;
  onMinimize: (id: string) => void;
  onMaximize: (id: string) => void;
  onRestore: (id: string) => void;
  onUpdatePosition: (id: string, x: number, y: number) => void;
  onUpdateSize: (id: string, width: number, height: number) => void;
  onUpdateTitle: (id: string, title: string) => void;
  hardware: ReturnType<typeof useHardwareMonitor>;
  fileSystem: ReturnType<typeof useFileSystem>;
  terminal: ReturnType<typeof useTerminal>;
  aiControl: ReturnType<typeof useAIAgentControl>;
}

const APP_TITLES: Record<string, string> = {
  terminal: 'Terminal',
  files: 'File Manager',
  browser: 'Browser',
  editor: 'Text Editor',
  settings: 'Settings',
  aichat: 'AI Chat',
  python: 'Python IDE',
  hardware: 'Hardware Monitor',
  airouter: 'AI Router',
  desktop: 'Desktop',
};

export function WindowManager({
  windows,
  onFocus,
  onClose,
  onMinimize,
  onMaximize,
  onRestore: _onRestore,
  onUpdatePosition,
  onUpdateSize,
  onUpdateTitle,
  hardware,
  fileSystem,
  terminal,
  aiControl,
}: WindowManagerProps) {
  const [resizing, setResizing] = useState<{ id: string; startX: number; startY: number; startWidth: number; startHeight: number } | null>(null);
  const [dragging, setDragging] = useState<{ id: string; offsetX: number; offsetY: number } | null>(null);

  // Handle window dragging
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (dragging) {
        const win = windows.find(w => w.id === dragging.id);
        if (win && !win.isMaximized) {
          const newX = e.clientX - dragging.offsetX;
          const newY = e.clientY - dragging.offsetY;
          onUpdatePosition(dragging.id, Math.max(0, newX), Math.max(0, newY));
        }
      }
      if (resizing) {
        const newWidth = Math.max(400, resizing.startWidth + (e.clientX - resizing.startX));
        const newHeight = Math.max(300, resizing.startHeight + (e.clientY - resizing.startY));
        onUpdateSize(resizing.id, newWidth, newHeight);
      }
    };

    const handleMouseUp = () => {
      setDragging(null);
      setResizing(null);
    };

    if (dragging || resizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [dragging, resizing, windows, onUpdatePosition, onUpdateSize]);

  const handleMouseDown = (e: React.MouseEvent, win: Window, action: 'drag' | 'resize') => {
    e.preventDefault();
    onFocus(win.id);

    if (action === 'drag' && !win.isMaximized) {
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      setDragging({
        id: win.id,
        offsetX: e.clientX - rect.left,
        offsetY: e.clientY - rect.top,
      });
    } else if (action === 'resize') {
      setResizing({
        id: win.id,
        startX: e.clientX,
        startY: e.clientY,
        startWidth: win.width,
        startHeight: win.height,
      });
    }
  };

  const renderWindowContent = (win: Window) => {
    const props = {
      windowId: win.id,
      onTitleChange: (title: string) => onUpdateTitle(win.id, title),
    };

    switch (win.appType) {
      case 'terminal':
        return <TerminalWindow {...props} terminal={terminal} />;
      case 'files':
        return <FileManagerWindow {...props} fileSystem={fileSystem} />;
      case 'browser':
        return <BrowserWindow {...props} initialUrl={win.content?.url} />;
      case 'editor':
        return <EditorWindow {...props} fileSystem={fileSystem} initialFile={win.content?.fileId} />;
      case 'settings':
        return <SettingsWindow {...props} hardware={hardware} aiControl={aiControl} />;
      case 'aichat':
        return <AIChatWindow {...props} aiControl={aiControl} />;
      case 'python':
        return <PythonWindow {...props} />;
      case 'hardware':
        return <HardwareWindow {...props} hardware={hardware} />;
      case 'airouter':
        return <AIRouterWindow {...props} aiControl={aiControl} />;
      default:
        return <div className="p-4 text-white/70">Unknown application</div>;
    }
  };

  return (
    <div className="absolute inset-0 pt-10 pb-12 overflow-hidden pointer-events-none">
      {windows.map((win) => (
        <div
          key={win.id}
          className={`absolute pointer-events-auto transition-shadow ${
            win.isFocused ? 'shadow-2xl' : 'shadow-lg'
          }`}
          style={{
            left: win.isMaximized ? 0 : win.x,
            top: win.isMaximized ? 0 : win.y,
            width: win.isMaximized ? '100%' : win.width,
            height: win.isMaximized ? 'calc(100% - 48px)' : win.height,
            zIndex: win.zIndex,
            opacity: win.isMinimized ? 0 : 1,
            visibility: win.isMinimized ? 'hidden' : 'visible',
          }}
        >
          {/* Window Frame */}
          <div 
            className={`w-full h-full flex flex-col rounded-xl overflow-hidden border ${
              win.isFocused 
                ? 'bg-slate-900/98 border-blue-500/30' 
                : 'bg-slate-900/95 border-white/10'
            }`}
            onClick={() => onFocus(win.id)}
          >
            {/* Title Bar */}
            <div 
              className="h-9 flex items-center justify-between px-3 bg-gradient-to-r from-slate-800/80 to-slate-800/40 border-b border-white/5"
              onMouseDown={(e) => handleMouseDown(e, win, 'drag')}
            >
              <div className="flex items-center gap-2">
                <GripVertical className="w-4 h-4 text-white/20" />
                <span className="text-sm text-white/90 font-medium truncate max-w-[200px]">
                  {win.title || APP_TITLES[win.appType]}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  className="w-6 h-6 rounded-md flex items-center justify-center hover:bg-white/10 transition-all"
                  onClick={() => onMinimize(win.id)}
                >
                  <Minus className="w-3 h-3 text-white/70" />
                </button>
                <button
                  className="w-6 h-6 rounded-md flex items-center justify-center hover:bg-white/10 transition-all"
                  onClick={() => onMaximize(win.id)}
                >
                  {win.isMaximized ? (
                    <Minimize2 className="w-3 h-3 text-white/70" />
                  ) : (
                    <Maximize2 className="w-3 h-3 text-white/70" />
                  )}
                </button>
                <button
                  className="w-6 h-6 rounded-md flex items-center justify-center hover:bg-red-500/80 transition-all"
                  onClick={() => onClose(win.id)}
                >
                  <X className="w-3 h-3 text-white/70" />
                </button>
              </div>
            </div>

            {/* Window Content */}
            <div className="flex-1 overflow-hidden">
              {renderWindowContent(win)}
            </div>

            {/* Resize Handle */}
            {!win.isMaximized && (
              <div
                className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize"
                onMouseDown={(e) => handleMouseDown(e, win, 'resize')}
              >
                <svg className="w-full h-full text-white/20" viewBox="0 0 16 16">
                  <path
                    fill="currentColor"
                    d="M11 11h4v4h-4zM6 11h4v4H6zM11 6h4v4h-4z"
                  />
                </svg>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
