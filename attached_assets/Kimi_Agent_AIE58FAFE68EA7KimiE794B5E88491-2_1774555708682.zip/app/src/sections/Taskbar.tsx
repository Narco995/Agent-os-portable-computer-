import { useState, useEffect } from 'react';
import type { Window } from '@/types/system';
import { useHardwareMonitor } from '@/hooks/useHardwareMonitor';
import { useAIAgentControl } from '@/hooks/useAIAgentControl';
import { useComputerUse } from '@/hooks/useComputerUse';
import {
  Terminal,
  FolderOpen,
  Globe,
  FileCode,
  Settings,
  MessageSquare,
  Cpu,
  Bot,
  Code2,
  Wifi,
  Battery,
  Volume2,
  Bell,
  Monitor,
  Cloud,
  Zap,
  Laptop,
  Eye,
} from 'lucide-react';

interface TaskbarProps {
  windows: Window[];
  activeWindowId: string | null;
  onWindowClick: (id: string) => void;
  onAppLaunch: (appType: any) => void;
  onAIPanelToggle: () => void;
  onComputerUseToggle: () => void;
  systemTime: Date;
  hardware: ReturnType<typeof useHardwareMonitor>;
  aiControl: ReturnType<typeof useAIAgentControl>;
  computerUse: ReturnType<typeof useComputerUse>;
}

const APP_ICONS: Record<string, { icon: React.ReactNode; color: string }> = {
  terminal: { icon: <Terminal className="w-4 h-4" />, color: 'bg-green-500/20 text-green-400' },
  files: { icon: <FolderOpen className="w-4 h-4" />, color: 'bg-yellow-500/20 text-yellow-400' },
  browser: { icon: <Globe className="w-4 h-4" />, color: 'bg-blue-500/20 text-blue-400' },
  editor: { icon: <FileCode className="w-4 h-4" />, color: 'bg-orange-500/20 text-orange-400' },
  settings: { icon: <Settings className="w-4 h-4" />, color: 'bg-gray-500/20 text-gray-400' },
  aichat: { icon: <MessageSquare className="w-4 h-4" />, color: 'bg-purple-500/20 text-purple-400' },
  python: { icon: <Code2 className="w-4 h-4" />, color: 'bg-blue-600/20 text-blue-400' },
  hardware: { icon: <Cpu className="w-4 h-4" />, color: 'bg-red-500/20 text-red-400' },
  airouter: { icon: <Bot className="w-4 h-4" />, color: 'bg-indigo-500/20 text-indigo-400' },
};

const COMPUTE_MODE_ICONS = {
  local: { icon: Laptop, color: 'text-green-400', label: 'Local' },
  hybrid: { icon: Zap, color: 'text-yellow-400', label: 'Hybrid' },
  cloud: { icon: Cloud, color: 'text-blue-400', label: 'Cloud' },
};

export function Taskbar({
  windows,
  activeWindowId,
  onWindowClick,
  onAppLaunch,
  onAIPanelToggle,
  onComputerUseToggle,
  systemTime,
  hardware,
  aiControl,
  computerUse,
}: TaskbarProps) {
  const [showStartMenu, setShowStartMenu] = useState(false);
  const [showSysTray, setShowSysTray] = useState(false);
  const [showComputeMenu, setShowComputeMenu] = useState(false);

  const computeMode = hardware.computeMode;
  const ComputeIcon = COMPUTE_MODE_ICONS[computeMode].icon;

  // Close menus when clicking outside
  useEffect(() => {
    const handleClick = () => {
      setShowStartMenu(false);
      setShowSysTray(false);
      setShowComputeMenu(false);
    };
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 h-12 bg-slate-900/95 backdrop-blur-xl border-t border-white/10 flex items-center justify-between px-2 z-[1000]">
      {/* Left: Start Button + Pinned Apps */}
      <div className="flex items-center gap-1">
        {/* Start Button */}
        <button
          className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
            showStartMenu ? 'bg-blue-500/30' : 'hover:bg-white/10'
          }`}
          onClick={(e) => {
            e.stopPropagation();
            setShowStartMenu(!showStartMenu);
          }}
        >
          <div className="w-6 h-6 bg-gradient-to-br from-cyan-400 to-purple-500 rounded-md flex items-center justify-center">
            <span className="text-white text-xs font-bold">K</span>
          </div>
        </button>

        <div className="w-px h-6 bg-white/10 mx-1" />

        {/* Pinned Apps */}
        <div className="flex items-center gap-1">
          {['terminal', 'files', 'browser', 'editor', 'aichat'].map((app) => (
            <button
              key={app}
              className="w-10 h-10 rounded-lg flex items-center justify-center transition-all hover:bg-white/10"
              onClick={() => onAppLaunch(app)}
              title={app.charAt(0).toUpperCase() + app.slice(1)}
            >
              <div className={APP_ICONS[app]?.color || ''}>
                {APP_ICONS[app]?.icon}
              </div>
            </button>
          ))}
        </div>

        <div className="w-px h-6 bg-white/10 mx-1" />

        {/* Window Previews */}
        <div className="flex items-center gap-1">
          {windows.filter(w => !w.isMinimized).map((win) => (
            <button
              key={win.id}
              className={`h-10 px-3 rounded-lg flex items-center gap-2 transition-all max-w-[160px] ${
                win.id === activeWindowId
                  ? 'bg-white/10 border-b-2 border-blue-400'
                  : 'hover:bg-white/5'
              }`}
              onClick={() => onWindowClick(win.id)}
            >
              <div className={APP_ICONS[win.appType]?.color || ''}>
                {APP_ICONS[win.appType]?.icon}
              </div>
              <span className="text-xs text-white/80 truncate">{win.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Right: System Tray */}
      <div className="flex items-center gap-1">
        {/* Computer-Use Status */}
        <button
          className={`h-10 px-2 rounded-lg flex items-center gap-2 transition-all ${
            computerUse.isActive ? 'bg-purple-500/20' : 'hover:bg-white/10'
          }`}
          onClick={(e) => {
            e.stopPropagation();
            onComputerUseToggle();
          }}
          title="Computer-Use Panel"
        >
          <Eye className={`w-4 h-4 ${computerUse.isActive ? 'text-purple-400' : 'text-white/50'}`} />
          <span className="text-xs text-white/70 hidden sm:inline">Computer</span>
        </button>

        {/* AI Agent Status */}
        <button
          className={`h-10 px-2 rounded-lg flex items-center gap-2 transition-all ${
            aiControl.isListening ? 'bg-green-500/20' : 'hover:bg-white/10'
          }`}
          onClick={(e) => {
            e.stopPropagation();
            onAIPanelToggle();
          }}
          title="AI Control Panel"
        >
          <Bot className={`w-4 h-4 ${aiControl.isListening ? 'text-green-400' : 'text-white/50'}`} />
          <span className="text-xs text-white/70">
            {aiControl.agents.length} agent{aiControl.agents.length !== 1 ? 's' : ''}
          </span>
        </button>

        {/* Compute Mode */}
        <button
          className="h-10 px-2 rounded-lg flex items-center gap-2 hover:bg-white/10 transition-all"
          onClick={(e) => {
            e.stopPropagation();
            setShowComputeMenu(!showComputeMenu);
          }}
        >
          <ComputeIcon className={`w-4 h-4 ${COMPUTE_MODE_ICONS[computeMode].color}`} />
          <span className="text-xs text-white/70 hidden sm:inline">{COMPUTE_MODE_ICONS[computeMode].label}</span>
        </button>

        {/* Hardware Quick View */}
        <div className="h-10 px-2 rounded-lg flex items-center gap-3 hover:bg-white/10 transition-all">
          <div className="flex items-center gap-1">
            <Cpu className="w-3 h-3 text-cyan-400" />
            <span className="text-xs text-white/70">{hardware.stats.cpu.usage}%</span>
          </div>
          <div className="flex items-center gap-1">
            <Monitor className="w-3 h-3 text-purple-400" />
            <span className="text-xs text-white/70">{hardware.stats.memory.percentage}%</span>
          </div>
        </div>

        <div className="w-px h-6 bg-white/10 mx-1" />

        {/* System Icons */}
        <div className="flex items-center gap-1">
          <button className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/10 transition-all">
            <Wifi className="w-4 h-4 text-white/70" />
          </button>
          <button className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/10 transition-all">
            <Volume2 className="w-4 h-4 text-white/70" />
          </button>
          <button className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/10 transition-all">
            <Battery className="w-4 h-4 text-green-400" />
          </button>
        </div>

        {/* Clock */}
        <button
          className="h-10 px-3 rounded-lg hover:bg-white/10 transition-all text-right"
          onClick={(e) => {
            e.stopPropagation();
            setShowSysTray(!showSysTray);
          }}
        >
          <div className="text-xs text-white/90 font-medium">{formatTime(systemTime)}</div>
          <div className="text-[10px] text-white/50">{formatDate(systemTime)}</div>
        </button>

        {/* Show Desktop */}
        <button
          className="w-2 h-10 border-l border-white/10 hover:bg-white/10 transition-all"
          onClick={() => {
            windows.forEach(w => {
              if (!w.isMinimized) {
                onWindowClick(w.id);
              }
            });
          }}
          title="Show Desktop"
        />
      </div>

      {/* Start Menu */}
      {showStartMenu && (
        <div
          className="fixed bottom-14 left-2 w-80 bg-slate-900/95 backdrop-blur-xl rounded-xl border border-white/10 shadow-2xl overflow-hidden z-[1001]"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="p-4">
            <div className="text-sm font-semibold text-white/70 mb-3">Applications</div>
            <div className="grid grid-cols-4 gap-2">
              {Object.entries(APP_ICONS).map(([app, { icon, color }]) => (
                <button
                  key={app}
                  className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-white/10 transition-all"
                  onClick={() => {
                    onAppLaunch(app);
                    setShowStartMenu(false);
                  }}
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
                    {icon}
                  </div>
                  <span className="text-[10px] text-white/70 capitalize">{app}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="border-t border-white/10 p-3 bg-white/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center">
                  <span className="text-white text-xs font-bold">U</span>
                </div>
                <span className="text-sm text-white/90">User</span>
              </div>
              <button className="p-2 rounded-lg hover:bg-white/10 transition-all">
                <Settings className="w-4 h-4 text-white/70" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Compute Mode Menu */}
      {showComputeMenu && (
        <div
          className="fixed bottom-14 right-40 w-48 bg-slate-900/95 backdrop-blur-xl rounded-xl border border-white/10 shadow-2xl overflow-hidden z-[1001]"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="p-2">
            {(['local', 'hybrid', 'cloud'] as const).map((mode) => {
              const ModeIcon = COMPUTE_MODE_ICONS[mode].icon;
              return (
                <button
                  key={mode}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all ${
                    computeMode === mode ? 'bg-blue-500/20' : 'hover:bg-white/10'
                  }`}
                  onClick={() => {
                    hardware.setComputeMode(mode);
                    setShowComputeMenu(false);
                  }}
                >
                  <ModeIcon className={`w-4 h-4 ${COMPUTE_MODE_ICONS[mode].color}`} />
                  <span className="text-sm text-white/90 capitalize">{mode}</span>
                  {computeMode === mode && (
                    <div className="ml-auto w-2 h-2 rounded-full bg-blue-400" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* System Tray Menu */}
      {showSysTray && (
        <div
          className="fixed bottom-14 right-2 w-64 bg-slate-900/95 backdrop-blur-xl rounded-xl border border-white/10 shadow-2xl overflow-hidden z-[1001]"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/70">Network</span>
              <Wifi className="w-4 h-4 text-green-400" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/70">Volume</span>
              <Volume2 className="w-4 h-4 text-white/70" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/70">Battery</span>
              <div className="flex items-center gap-2">
                <span className="text-xs text-white/50">85%</span>
                <Battery className="w-4 h-4 text-green-400" />
              </div>
            </div>
            <div className="border-t border-white/10 pt-3">
              <div className="text-xs text-white/50 mb-2">Notifications</div>
              <div className="flex items-center gap-2 text-sm text-white/70">
                <Bell className="w-4 h-4" />
                <span>No new notifications</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
