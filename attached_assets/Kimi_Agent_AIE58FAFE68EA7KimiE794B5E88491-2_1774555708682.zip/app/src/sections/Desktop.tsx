import { useState, useCallback } from 'react';
import type { AppType } from '@/types/system';
import { 
  Terminal, 
  FolderOpen, 
  Globe, 
  FileCode, 
  Settings, 
  MessageSquare, 
  Cpu, 
  Bot,
  Code2,
  LayoutGrid
} from 'lucide-react';

interface DesktopProps {
  onAppLaunch: (appType: AppType) => void;
}

interface DesktopIcon {
  id: AppType;
  name: string;
  icon: React.ReactNode;
  x: number;
  y: number;
}

const DESKTOP_ICONS: DesktopIcon[] = [
  { id: 'terminal', name: 'Terminal', icon: <Terminal className="w-8 h-8" />, x: 20, y: 20 },
  { id: 'aichat', name: 'AI Chat', icon: <MessageSquare className="w-8 h-8" />, x: 20, y: 120 },
  { id: 'files', name: 'Files', icon: <FolderOpen className="w-8 h-8" />, x: 20, y: 220 },
  { id: 'browser', name: 'Browser', icon: <Globe className="w-8 h-8" />, x: 20, y: 320 },
  { id: 'editor', name: 'Editor', icon: <FileCode className="w-8 h-8" />, x: 20, y: 420 },
  { id: 'python', name: 'Python', icon: <Code2 className="w-8 h-8" />, x: 20, y: 520 },
  { id: 'hardware', name: 'Hardware', icon: <Cpu className="w-8 h-8" />, x: 120, y: 20 },
  { id: 'airouter', name: 'AI Router', icon: <Bot className="w-8 h-8" />, x: 120, y: 120 },
  { id: 'settings', name: 'Settings', icon: <Settings className="w-8 h-8" />, x: 120, y: 220 },
];

export function Desktop({ onAppLaunch }: DesktopProps) {
  const [selectedIcon, setSelectedIcon] = useState<string | null>(null);
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; visible: boolean }>(
    { x: 0, y: 0, visible: false }
  );

  const handleIconClick = useCallback((id: string) => {
    setSelectedIcon(id);
  }, []);

  const handleIconDoubleClick = useCallback((id: AppType) => {
    onAppLaunch(id);
    setSelectedIcon(null);
  }, [onAppLaunch]);

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY, visible: true });
  }, []);

  const handleDesktopClick = useCallback(() => {
    setSelectedIcon(null);
    setContextMenu(prev => ({ ...prev, visible: false }));
  }, []);

  return (
    <div 
      className="absolute inset-0 pt-2 pb-16 px-2"
      onClick={handleDesktopClick}
      onContextMenu={handleContextMenu}
    >
      {/* Desktop Grid */}
      <div className="grid grid-cols-[repeat(auto-fill,80px)] gap-2 content-start">
        {DESKTOP_ICONS.map((icon) => (
          <div
            key={icon.id}
            className={`
              flex flex-col items-center gap-1 p-2 rounded-lg cursor-pointer
              transition-all duration-150 select-none
              ${selectedIcon === icon.id 
                ? 'bg-blue-500/30 ring-2 ring-blue-400' 
                : 'hover:bg-white/10'
              }
            `}
            onClick={(e) => {
              e.stopPropagation();
              handleIconClick(icon.id);
            }}
            onDoubleClick={(e) => {
              e.stopPropagation();
              handleIconDoubleClick(icon.id);
            }}
          >
            <div className={`
              w-12 h-12 flex items-center justify-center rounded-xl
              ${icon.id === 'terminal' && 'bg-gray-800/80 text-green-400'}
              ${icon.id === 'aichat' && 'bg-purple-600/80 text-white'}
              ${icon.id === 'files' && 'bg-yellow-500/80 text-white'}
              ${icon.id === 'browser' && 'bg-blue-500/80 text-white'}
              ${icon.id === 'editor' && 'bg-orange-500/80 text-white'}
              ${icon.id === 'python' && 'bg-blue-600/80 text-yellow-300'}
              ${icon.id === 'hardware' && 'bg-red-500/80 text-white'}
              ${icon.id === 'airouter' && 'bg-indigo-500/80 text-white'}
              ${icon.id === 'settings' && 'bg-gray-500/80 text-white'}
              shadow-lg backdrop-blur-sm
            `}>
              {icon.icon}
            </div>
            <span className={`
              text-xs text-center px-1 rounded
              ${selectedIcon === icon.id 
                ? 'bg-blue-500 text-white' 
                : 'text-white/90 bg-black/40'
              }
            `}>
              {icon.name}
            </span>
          </div>
        ))}
      </div>

      {/* Desktop Context Menu */}
      {contextMenu.visible && (
        <div 
          className="fixed bg-slate-800/95 backdrop-blur-md rounded-lg shadow-xl border border-white/10 py-1 z-[9999] min-w-[160px]"
          style={{ left: contextMenu.x, top: contextMenu.y }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-3 py-2 text-xs text-white/50 border-b border-white/10 mb-1">
            Desktop
          </div>
          <button 
            className="w-full px-3 py-2 text-left text-sm text-white/90 hover:bg-white/10 flex items-center gap-2"
            onClick={() => {
              onAppLaunch('terminal');
              setContextMenu(prev => ({ ...prev, visible: false }));
            }}
          >
            <Terminal className="w-4 h-4" />
            Open Terminal
          </button>
          <button 
            className="w-full px-3 py-2 text-left text-sm text-white/90 hover:bg-white/10 flex items-center gap-2"
            onClick={() => {
              onAppLaunch('settings');
              setContextMenu(prev => ({ ...prev, visible: false }));
            }}
          >
            <Settings className="w-4 h-4" />
            System Settings
          </button>
          <div className="border-t border-white/10 my-1" />
          <button 
            className="w-full px-3 py-2 text-left text-sm text-white/90 hover:bg-white/10 flex items-center gap-2"
            onClick={() => setContextMenu(prev => ({ ...prev, visible: false }))}
          >
            <LayoutGrid className="w-4 h-4" />
            Refresh Desktop
          </button>
        </div>
      )}
    </div>
  );
}
