import { useState, useRef, useEffect } from 'react';
import { useComputerUse, ComputerActions } from '@/hooks/useComputerUse';
import {
  X,
  Monitor,
  MousePointer,
  Keyboard,
  Camera,
  Play,
  Square,
  RotateCcw,
  Eye,
  Terminal,
  CheckCircle,
  Clock,
  Copy,
  Check,
  Move,
  Type,
  ScrollText,
} from 'lucide-react';
import { toast } from 'sonner';

interface ComputerUsePanelProps {
  computerUse: ReturnType<typeof useComputerUse>;
  onClose: () => void;
}

export function ComputerUsePanel({ computerUse, onClose }: ComputerUsePanelProps) {
  const [activeTab, setActiveTab] = useState<'control' | 'tasks' | 'history'>('control');
  const [actionX, setActionX] = useState(100);
  const [actionY, setActionY] = useState(100);
  const [actionText, setActionText] = useState('');
  const [actionKey, setActionKey] = useState('');
  const [scrollDelta, setScrollDelta] = useState(100);
  const [waitTime, setWaitTime] = useState(1000);
  const [copiedScreenshot, setCopiedScreenshot] = useState(false);
  const screenshotRef = useRef<HTMLImageElement>(null);

  const { 
    isActive, 
    currentTask, 
    screenshot, 
    cursorPosition, 
    isProcessing,
    executeAction,
    startTask,
    completeTask,
    cancelTask,
  } = computerUse;

  // Auto-refresh screenshot when active
  useEffect(() => {
    if (isActive) {
      const interval = setInterval(() => {
        executeAction(ComputerActions.screenshot());
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [isActive, executeAction]);

  const handleExecuteAction = async (actionType: string) => {
    try {
      let action;
      switch (actionType) {
        case 'screenshot':
          action = ComputerActions.screenshot();
          break;
        case 'click':
          action = ComputerActions.click(actionX, actionY);
          break;
        case 'doubleClick':
          action = ComputerActions.doubleClick(actionX, actionY);
          break;
        case 'move':
          action = ComputerActions.move(actionX, actionY);
          break;
        case 'type':
          action = ComputerActions.type(actionText);
          setActionText('');
          break;
        case 'keypress':
          action = ComputerActions.keypress(actionKey);
          setActionKey('');
          break;
        case 'scroll':
          action = ComputerActions.scroll(0, scrollDelta);
          break;
        case 'wait':
          action = ComputerActions.wait(waitTime);
          break;
        default:
          return;
      }

      await executeAction(action);
      toast.success(`${actionType} executed successfully`);
    } catch (error) {
      toast.error(`Failed to execute ${actionType}`);
    }
  };

  const handleCopyScreenshot = () => {
    if (screenshot) {
      navigator.clipboard.writeText(screenshot);
      setCopiedScreenshot(true);
      setTimeout(() => setCopiedScreenshot(false), 2000);
    }
  };

  return (
    <div className="fixed top-16 right-4 w-[520px] max-h-[85vh] bg-slate-900/98 backdrop-blur-xl rounded-xl border border-white/10 shadow-2xl overflow-hidden z-[1000] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-purple-600/20 to-pink-600/20 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Monitor className="w-5 h-5 text-purple-400" />
          <span className="font-semibold text-white/90">Computer-Use Agent</span>
          <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`} />
        </div>
        <button onClick={onClose} className="p-1 rounded-lg hover:bg-white/10 transition-all">
          <X className="w-4 h-4 text-white/70" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10">
        {(['control', 'tasks', 'history'] as const).map((tab) => (
          <button
            key={tab}
            className={`flex-1 px-4 py-2 text-sm font-medium transition-all ${
              activeTab === tab
                ? 'text-purple-400 border-b-2 border-purple-400 bg-purple-500/10'
                : 'text-white/60 hover:text-white/90 hover:bg-white/5'
            }`}
            onClick={() => setActiveTab(tab)}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        {activeTab === 'control' && (
          <div className="space-y-4">
            {/* Live Screenshot */}
            <div className="p-3 bg-white/5 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-white/70 flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Live View
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleExecuteAction('screenshot')}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-all"
                    title="Capture screenshot"
                  >
                    <Camera className="w-4 h-4 text-white/70" />
                  </button>
                  <button
                    onClick={handleCopyScreenshot}
                    disabled={!screenshot}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-all disabled:opacity-50"
                    title="Copy screenshot"
                  >
                    {copiedScreenshot ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-white/70" />}
                  </button>
                </div>
              </div>
              <div className="aspect-video bg-slate-950 rounded-lg overflow-hidden border border-white/10">
                {screenshot ? (
                  <img 
                    ref={screenshotRef}
                    src={screenshot} 
                    alt="Desktop screenshot" 
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-white/30">
                    <div className="text-center">
                      <Camera className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Click camera to capture</p>
                    </div>
                  </div>
                )}
              </div>
              <div className="flex items-center justify-between mt-2 text-xs text-white/50">
                <span>Cursor: {cursorPosition.x}, {cursorPosition.y}</span>
                {isProcessing && <span className="text-yellow-400">Processing...</span>}
              </div>
            </div>

            {/* Mouse Controls */}
            <div className="p-3 bg-white/5 rounded-lg">
              <div className="text-sm font-medium text-white/70 mb-3 flex items-center gap-2">
                <MousePointer className="w-4 h-4" />
                Mouse Controls
              </div>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="text-xs text-white/50 block mb-1">X Position</label>
                  <input
                    type="number"
                    value={actionX}
                    onChange={(e) => setActionX(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90"
                  />
                </div>
                <div>
                  <label className="text-xs text-white/50 block mb-1">Y Position</label>
                  <input
                    type="number"
                    value={actionY}
                    onChange={(e) => setActionY(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90"
                  />
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleExecuteAction('click')}
                  disabled={isProcessing}
                  className="px-3 py-1.5 bg-purple-500/20 text-purple-400 rounded-lg text-sm hover:bg-purple-500/30 disabled:opacity-50 transition-all"
                >
                  Click
                </button>
                <button
                  onClick={() => handleExecuteAction('doubleClick')}
                  disabled={isProcessing}
                  className="px-3 py-1.5 bg-purple-500/20 text-purple-400 rounded-lg text-sm hover:bg-purple-500/30 disabled:opacity-50 transition-all"
                >
                  Double Click
                </button>
                <button
                  onClick={() => handleExecuteAction('move')}
                  disabled={isProcessing}
                  className="px-3 py-1.5 bg-purple-500/20 text-purple-400 rounded-lg text-sm hover:bg-purple-500/30 disabled:opacity-50 transition-all"
                >
                  <Move className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Keyboard Controls */}
            <div className="p-3 bg-white/5 rounded-lg">
              <div className="text-sm font-medium text-white/70 mb-3 flex items-center gap-2">
                <Keyboard className="w-4 h-4" />
                Keyboard Controls
              </div>
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-white/50 block mb-1">Type Text</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={actionText}
                      onChange={(e) => setActionText(e.target.value)}
                      placeholder="Enter text to type..."
                      className="flex-1 px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90 placeholder:text-white/30"
                    />
                    <button
                      onClick={() => handleExecuteAction('type')}
                      disabled={isProcessing || !actionText}
                      className="px-3 py-2 bg-purple-500/20 text-purple-400 rounded-lg hover:bg-purple-500/30 disabled:opacity-50 transition-all"
                    >
                      <Type className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-white/50 block mb-1">Key Press</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={actionKey}
                      onChange={(e) => setActionKey(e.target.value)}
                      placeholder="e.g., Enter, Escape, Tab"
                      className="flex-1 px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90 placeholder:text-white/30"
                    />
                    <button
                      onClick={() => handleExecuteAction('keypress')}
                      disabled={isProcessing || !actionKey}
                      className="px-3 py-2 bg-purple-500/20 text-purple-400 rounded-lg hover:bg-purple-500/30 disabled:opacity-50 transition-all"
                    >
                      Press
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Scroll & Wait */}
            <div className="p-3 bg-white/5 rounded-lg">
              <div className="text-sm font-medium text-white/70 mb-3 flex items-center gap-2">
                <ScrollText className="w-4 h-4" />
                Scroll & Wait
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-white/50 block mb-1">Scroll Delta</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={scrollDelta}
                      onChange={(e) => setScrollDelta(Number(e.target.value))}
                      className="flex-1 px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90"
                    />
                    <button
                      onClick={() => handleExecuteAction('scroll')}
                      disabled={isProcessing}
                      className="px-3 py-2 bg-purple-500/20 text-purple-400 rounded-lg hover:bg-purple-500/30 disabled:opacity-50 transition-all"
                    >
                      Scroll
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-white/50 block mb-1">Wait (ms)</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={waitTime}
                      onChange={(e) => setWaitTime(Number(e.target.value))}
                      step={100}
                      className="flex-1 px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90"
                    />
                    <button
                      onClick={() => handleExecuteAction('wait')}
                      disabled={isProcessing}
                      className="px-3 py-2 bg-purple-500/20 text-purple-400 rounded-lg hover:bg-purple-500/30 disabled:opacity-50 transition-all"
                    >
                      <Clock className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Task Controls */}
            {currentTask && (
              <div className="p-3 bg-purple-500/10 rounded-lg border border-purple-500/30">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-purple-400">Active Task</span>
                  <button
                    onClick={cancelTask}
                    className="p-1.5 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-all"
                  >
                    <Square className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-sm text-white/70">{currentTask.description}</p>
                <div className="mt-2 text-xs text-white/50">
                  {currentTask.steps.length} steps
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'tasks' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-white/70">Active Tasks</span>
              <button
                onClick={() => startTask('Manual computer-use task', 'user')}
                className="flex items-center gap-2 px-3 py-1.5 bg-purple-500/20 text-purple-400 rounded-lg text-sm hover:bg-purple-500/30 transition-all"
              >
                <Play className="w-4 h-4" />
                New Task
              </button>
            </div>

            {currentTask ? (
              <div className="p-3 bg-white/5 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                    <span className="text-sm text-white/90">{currentTask.description}</span>
                  </div>
                  <button
                    onClick={() => completeTask()}
                    className="p-1.5 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 transition-all"
                  >
                    <CheckCircle className="w-4 h-4" />
                  </button>
                </div>
                <div className="text-xs text-white/50 mb-2">
                  Started: {currentTask.startedAt?.toLocaleTimeString()}
                </div>
                <div className="space-y-1">
                  {currentTask.steps.map((step, i) => (
                    <div key={step.id} className="flex items-start gap-2 text-xs">
                      <span className="text-white/30">{i + 1}.</span>
                      <span className="text-white/70">{step.content}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-white/30">
                <Terminal className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No active tasks</p>
                <p className="text-sm">Start a new task to begin</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-2">
            <div className="text-sm font-medium text-white/70 mb-2">Action History</div>
            {/* This would show historical actions */}
            <div className="text-center py-8 text-white/30">
              <RotateCcw className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>History will appear here</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
