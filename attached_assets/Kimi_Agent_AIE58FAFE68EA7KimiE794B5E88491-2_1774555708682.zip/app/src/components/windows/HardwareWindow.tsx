import { useState, useEffect } from 'react';
import { useHardwareMonitor } from '@/hooks/useHardwareMonitor';
import {
  Cpu,
  MemoryStick,
  HardDrive,
  Wifi,
  Activity,
  TrendingUp,
  TrendingDown,
  Zap,
  Monitor,
  Server,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface HardwareWindowProps {
  windowId: string;
  onTitleChange: (title: string) => void;
  hardware: ReturnType<typeof useHardwareMonitor>;
}

export function HardwareWindow({ hardware }: HardwareWindowProps) {
  const { stats, history, computeMode, setComputeMode, getNPUStatus } = hardware;
  const [activeTab, setActiveTab] = useState<'overview' | 'cpu' | 'memory' | 'network' | 'storage'>('overview');
  const [npuStatus, setNpuStatus] = useState(getNPUStatus());

  // Update NPU status periodically
  useEffect(() => {
    const interval = setInterval(() => {
      setNpuStatus(getNPUStatus());
    }, 3000);
    return () => clearInterval(interval);
  }, [getNPUStatus]);

  const getUsageColor = (usage: number) => {
    if (usage < 50) return 'text-green-400';
    if (usage < 80) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="w-full h-full flex flex-col bg-slate-900">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800/50 border-b border-white/5">
        <div className="flex items-center gap-3">
          <Activity className="w-5 h-5 text-blue-400" />
          <span className="font-semibold text-white/90">Hardware Monitor</span>
        </div>
        <div className="flex items-center gap-2">
          <div className={`px-3 py-1 rounded-full text-xs ${
            stats.network.status === 'online' 
              ? 'bg-green-500/20 text-green-400' 
              : 'bg-red-500/20 text-red-400'
          }`}>
            {stats.network.status === 'online' ? '● Online' : '● Offline'}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 px-4 py-2 border-b border-white/5">
        {[
          { id: 'overview', label: 'Overview', icon: Monitor },
          { id: 'cpu', label: 'CPU', icon: Cpu },
          { id: 'memory', label: 'Memory', icon: MemoryStick },
          { id: 'network', label: 'Network', icon: Wifi },
          { id: 'storage', label: 'Storage', icon: HardDrive },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-all ${
              activeTab === tab.id
                ? 'bg-blue-500/20 text-blue-400'
                : 'text-white/70 hover:bg-white/5'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {/* CPU Card */}
              <div className="p-4 bg-white/5 rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-5 h-5 text-cyan-400" />
                    <span className="text-sm text-white/70">CPU</span>
                  </div>
                  <span className={`text-2xl font-bold ${getUsageColor(stats.cpu.usage)}`}>
                    {stats.cpu.usage}%
                  </span>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-500"
                    style={{ width: `${stats.cpu.usage}%` }}
                  />
                </div>
                <div className="mt-2 text-xs text-white/50">
                  {stats.cpu.cores} cores @ {stats.cpu.frequency.toFixed(1)} GHz
                </div>
              </div>

              {/* Memory Card */}
              <div className="p-4 bg-white/5 rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <MemoryStick className="w-5 h-5 text-purple-400" />
                    <span className="text-sm text-white/70">Memory</span>
                  </div>
                  <span className={`text-2xl font-bold ${getUsageColor(stats.memory.percentage)}`}>
                    {stats.memory.percentage}%
                  </span>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-400 to-pink-500 transition-all duration-500"
                    style={{ width: `${stats.memory.percentage}%` }}
                  />
                </div>
                <div className="mt-2 text-xs text-white/50">
                  {stats.memory.used.toFixed(1)} / {stats.memory.total} GB
                </div>
              </div>

              {/* GPU Card */}
              <div className="p-4 bg-white/5 rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    <span className="text-sm text-white/70">GPU</span>
                  </div>
                  <span className={`text-2xl font-bold ${getUsageColor(stats.gpu?.usage || 0)}`}>
                    {stats.gpu?.usage || 0}%
                  </span>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-500"
                    style={{ width: `${stats.gpu?.usage || 0}%` }}
                  />
                </div>
                <div className="mt-2 text-xs text-white/50">
                  {stats.gpu?.memory.toFixed(1) || 0} GB VRAM
                </div>
              </div>

              {/* NPU Card */}
              <div className="p-4 bg-white/5 rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Server className="w-5 h-5 text-green-400" />
                    <span className="text-sm text-white/70">NPU</span>
                  </div>
                  <span className={`text-2xl font-bold ${
                    npuStatus.status === 'idle' ? 'text-green-400' :
                    npuStatus.status === 'active' ? 'text-yellow-400' : 'text-red-400'
                  }`}>
                    {Math.round(npuStatus.utilization)}%
                  </span>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ${
                      npuStatus.status === 'idle' ? 'bg-green-400' :
                      npuStatus.status === 'active' ? 'bg-yellow-400' : 'bg-red-400'
                    }`}
                    style={{ width: `${npuStatus.utilization}%` }}
                  />
                </div>
                <div className="mt-2 text-xs text-white/50 capitalize">
                  {npuStatus.status} • {npuStatus.model}
                </div>
              </div>
            </div>

            {/* Performance Chart */}
            <div className="p-4 bg-white/5 rounded-xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-white/90">Performance History</h3>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-cyan-400" />
                    <span className="text-white/50">CPU</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-purple-400" />
                    <span className="text-white/50">Memory</span>
                  </div>
                </div>
              </div>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={history}>
                    <defs>
                      <linearGradient id="cpuGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#22d3ee" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="memGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#c084fc" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#c084fc" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis 
                      dataKey="timestamp" 
                      tickFormatter={(v) => new Date(v).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      stroke="rgba(255,255,255,0.2)"
                      tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 10 }}
                    />
                    <YAxis 
                      stroke="rgba(255,255,255,0.2)"
                      tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 10 }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'rgba(15, 23, 42, 0.95)',
                        border: '1px solid rgba(255,255,255,0.1)',
                        borderRadius: '8px',
                      }}
                      labelStyle={{ color: 'rgba(255,255,255,0.7)' }}
                    />
                    <Area
                      type="monotone"
                      dataKey="cpu"
                      stroke="#22d3ee"
                      fillOpacity={1}
                      fill="url(#cpuGradient)"
                      strokeWidth={2}
                    />
                    <Area
                      type="monotone"
                      dataKey="memory"
                      stroke="#c084fc"
                      fillOpacity={1}
                      fill="url(#memGradient)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Compute Mode */}
            <div className="p-4 bg-white/5 rounded-xl">
              <h3 className="text-sm font-medium text-white/90 mb-4">Compute Mode</h3>
              <div className="flex gap-3">
                {(['local', 'hybrid', 'cloud'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setComputeMode(mode)}
                    className={`flex-1 p-4 rounded-lg border transition-all ${
                      computeMode === mode
                        ? 'bg-blue-500/20 border-blue-500/30'
                        : 'bg-white/5 border-transparent hover:bg-white/10'
                    }`}
                  >
                    <div className="text-sm font-medium text-white/90 capitalize">{mode}</div>
                    <div className="text-xs text-white/50 mt-1">
                      {mode === 'local' && 'Process on local hardware'}
                      {mode === 'hybrid' && 'Balance local and cloud'}
                      {mode === 'cloud' && 'Offload to cloud'}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'cpu' && (
          <div className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-white/5 rounded-xl text-center">
                <div className="text-3xl font-bold text-cyan-400">{stats.cpu.usage}%</div>
                <div className="text-sm text-white/50 mt-1">Usage</div>
              </div>
              <div className="p-4 bg-white/5 rounded-xl text-center">
                <div className="text-3xl font-bold text-orange-400">{stats.cpu.temperature}°C</div>
                <div className="text-sm text-white/50 mt-1">Temperature</div>
              </div>
              <div className="p-4 bg-white/5 rounded-xl text-center">
                <div className="text-3xl font-bold text-green-400">{stats.cpu.frequency.toFixed(1)}</div>
                <div className="text-sm text-white/50 mt-1">GHz</div>
              </div>
            </div>
            <div className="p-4 bg-white/5 rounded-xl">
              <h3 className="text-sm font-medium text-white/90 mb-4">CPU Cores</h3>
              <div className="grid grid-cols-4 gap-3">
                {Array.from({ length: stats.cpu.cores }).map((_, i) => (
                  <div key={i} className="p-3 bg-white/5 rounded-lg">
                    <div className="text-xs text-white/50 mb-1">Core {i + 1}</div>
                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-cyan-400 transition-all duration-500"
                        style={{ width: `${Math.random() * 40 + 30}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'memory' && (
          <div className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-white/5 rounded-xl text-center">
                <div className="text-3xl font-bold text-purple-400">{stats.memory.percentage}%</div>
                <div className="text-sm text-white/50 mt-1">Used</div>
              </div>
              <div className="p-4 bg-white/5 rounded-xl text-center">
                <div className="text-3xl font-bold text-green-400">{stats.memory.used.toFixed(1)}</div>
                <div className="text-sm text-white/50 mt-1">GB Used</div>
              </div>
              <div className="p-4 bg-white/5 rounded-xl text-center">
                <div className="text-3xl font-bold text-blue-400">{stats.memory.total}</div>
                <div className="text-sm text-white/50 mt-1">GB Total</div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'network' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-white/5 rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingDown className="w-5 h-5 text-green-400" />
                  <span className="text-sm text-white/70">Download</span>
                </div>
                <div className="text-3xl font-bold text-white/90">{stats.network.downloadSpeed.toFixed(1)}</div>
                <div className="text-sm text-white/50">MB/s</div>
              </div>
              <div className="p-4 bg-white/5 rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-blue-400" />
                  <span className="text-sm text-white/70">Upload</span>
                </div>
                <div className="text-3xl font-bold text-white/90">{stats.network.uploadSpeed.toFixed(1)}</div>
                <div className="text-sm text-white/50">MB/s</div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'storage' && (
          <div className="space-y-6">
            <div className="p-4 bg-white/5 rounded-xl">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-white/70">Main Drive</span>
                <span className="text-sm text-white/90">{stats.storage.used} / {stats.storage.total} GB</span>
              </div>
              <div className="h-4 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-400 to-purple-500 transition-all duration-500"
                  style={{ width: `${(stats.storage.used / stats.storage.total) * 100}%` }}
                />
              </div>
              <div className="mt-2 text-xs text-white/50">
                {Math.round((stats.storage.used / stats.storage.total) * 100)}% used
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
