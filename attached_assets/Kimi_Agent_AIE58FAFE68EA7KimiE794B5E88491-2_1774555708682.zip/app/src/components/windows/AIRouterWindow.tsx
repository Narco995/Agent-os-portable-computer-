import { useState, useEffect } from 'react';
import { useAIAgentControl } from '@/hooks/useAIAgentControl';
import {
  Bot,
  Server,
  Globe,
  Cpu,
  Cloud,
  Zap,
  CheckCircle,
  XCircle,
  Clock,
  Activity,
  Settings,
  Plus,
  Trash2,
  Edit2,
  Shield,
  Key,
  Webhook,
} from 'lucide-react';

interface AIRouterWindowProps {
  windowId: string;
  onTitleChange: (title: string) => void;
  aiControl: ReturnType<typeof useAIAgentControl>;
}

interface Route {
  id: string;
  name: string;
  type: 'local' | 'cloud' | 'hybrid';
  endpoint: string;
  status: 'active' | 'inactive' | 'error';
  latency: number;
  requests: number;
}

interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'warn' | 'error';
  message: string;
  agent?: string;
}

export function AIRouterWindow({ aiControl }: AIRouterWindowProps) {
  const [routes, setRoutes] = useState<Route[]>([
    { id: '1', name: 'Local Agent', type: 'local', endpoint: 'localhost:7777', status: 'active', latency: 12, requests: 1247 },
    { id: '2', name: 'Cloud Backup', type: 'cloud', endpoint: 'api.kimi.com', status: 'active', latency: 45, requests: 89 },
    { id: '3', name: 'Hybrid Router', type: 'hybrid', endpoint: 'router.kimi.local', status: 'inactive', latency: 0, requests: 0 },
  ]);
  
  const [logs, setLogs] = useState<LogEntry[]>([
    { id: '1', timestamp: new Date(), level: 'info', message: 'AI Router initialized', agent: 'system' },
    { id: '2', timestamp: new Date(Date.now() - 5000), level: 'info', message: 'Local agent connected', agent: 'Local Agent' },
    { id: '3', timestamp: new Date(Date.now() - 10000), level: 'info', message: 'Command executed: window.open', agent: 'Local Agent' },
  ]);
  
  const [activeTab, setActiveTab] = useState<'routes' | 'logs' | 'config'>('routes');
  const [showAddRoute, setShowAddRoute] = useState(false);
  const [newRoute, setNewRoute] = useState<{ name: string; type: 'local' | 'cloud' | 'hybrid'; endpoint: string }>({ name: '', type: 'local', endpoint: '' });

  // Simulate incoming logs
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        const newLog: LogEntry = {
          id: Date.now().toString(),
          timestamp: new Date(),
          level: Math.random() > 0.9 ? 'warn' : 'info',
          message: ['Heartbeat received', 'Command processed', 'Status check', 'Agent ping'][Math.floor(Math.random() * 4)],
          agent: 'Local Agent',
        };
        setLogs(prev => [newLog, ...prev].slice(0, 100));
      }
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const addRoute = () => {
    if (!newRoute.name || !newRoute.endpoint) return;
    
    const route: Route = {
      id: Date.now().toString(),
      name: newRoute.name,
      type: newRoute.type,
      endpoint: newRoute.endpoint,
      status: 'inactive',
      latency: 0,
      requests: 0,
    };
    
    setRoutes([...routes, route]);
    setNewRoute({ name: '', type: 'local', endpoint: '' });
    setShowAddRoute(false);
  };

  const toggleRoute = (id: string) => {
    setRoutes(prev => prev.map(r => 
      r.id === id ? { ...r, status: r.status === 'active' ? 'inactive' : 'active' } : r
    ));
  };

  const deleteRoute = (id: string) => {
    setRoutes(prev => prev.filter(r => r.id !== id));
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'local': return <Cpu className="w-4 h-4 text-green-400" />;
      case 'cloud': return <Cloud className="w-4 h-4 text-blue-400" />;
      case 'hybrid': return <Zap className="w-4 h-4 text-yellow-400" />;
      default: return <Server className="w-4 h-4" />;
    }
  };

  return (
    <div className="w-full h-full flex flex-col bg-slate-900">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-800/50 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-semibold text-white/90">AI Router</span>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-green-400">● {routes.filter(r => r.status === 'active').length} active</span>
              <span className="text-white/30">|</span>
              <span className="text-white/50">{aiControl.agents.length} agents</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddRoute(true)}
            className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-all"
          >
            <Plus className="w-4 h-4" />
            Add Route
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 px-4 py-2 border-b border-white/5">
        {[
          { id: 'routes', label: 'Routes', icon: Server },
          { id: 'logs', label: 'Logs', icon: Activity },
          { id: 'config', label: 'Configuration', icon: Settings },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-all ${
              activeTab === tab.id
                ? 'bg-blue-500/20 text-blue-400'
                : 'text-white/70 hover:bg-white/5'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        {activeTab === 'routes' && (
          <div className="space-y-3">
            {routes.map((route) => (
              <div
                key={route.id}
                className="p-4 bg-white/5 rounded-xl flex items-center justify-between"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                    {getTypeIcon(route.type)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-white/90">{route.name}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        route.status === 'active' ? 'bg-green-500/20 text-green-400' :
                        route.status === 'inactive' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>
                        {route.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-white/50 mt-1">
                      <span className="flex items-center gap-1">
                        <Globe className="w-3 h-3" />
                        {route.endpoint}
                      </span>
                      {route.status === 'active' && (
                        <>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {route.latency}ms
                          </span>
                          <span>{route.requests.toLocaleString()} requests</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleRoute(route.id)}
                    className={`p-2 rounded-lg transition-all ${
                      route.status === 'active'
                        ? 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                        : 'bg-white/5 text-white/50 hover:bg-white/10'
                    }`}
                  >
                    {route.status === 'active' ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => deleteRoute(route.id)}
                    className="p-2 rounded-lg bg-white/5 text-white/50 hover:bg-red-500/20 hover:text-red-400 transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-3 mt-6">
              <div className="p-4 bg-white/5 rounded-xl text-center">
                <div className="text-2xl font-bold text-green-400">
                  {routes.filter(r => r.status === 'active').length}
                </div>
                <div className="text-xs text-white/50 mt-1">Active Routes</div>
              </div>
              <div className="p-4 bg-white/5 rounded-xl text-center">
                <div className="text-2xl font-bold text-blue-400">
                  {routes.reduce((sum, r) => sum + r.requests, 0).toLocaleString()}
                </div>
                <div className="text-xs text-white/50 mt-1">Total Requests</div>
              </div>
              <div className="p-4 bg-white/5 rounded-xl text-center">
                <div className="text-2xl font-bold text-purple-400">
                  {Math.round(routes.filter(r => r.status === 'active').reduce((sum, r) => sum + r.latency, 0) / routes.filter(r => r.status === 'active').length || 0)}ms
                </div>
                <div className="text-xs text-white/50 mt-1">Avg Latency</div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="space-y-2">
            {logs.map((log) => (
              <div
                key={log.id}
                className="p-3 bg-white/5 rounded-lg flex items-start gap-3"
              >
                <div className={`w-2 h-2 rounded-full mt-1.5 ${
                  log.level === 'info' ? 'bg-blue-400' :
                  log.level === 'warn' ? 'bg-yellow-400' :
                  'bg-red-400'
                }`} />
                <div className="flex-1">
                  <div className="flex items-center gap-2 text-xs text-white/50">
                    <span>{log.timestamp.toLocaleTimeString()}</span>
                    {log.agent && (
                      <>
                        <span>•</span>
                        <span className="text-white/70">{log.agent}</span>
                      </>
                    )}
                  </div>
                  <div className="text-sm text-white/90 mt-0.5">{log.message}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'config' && (
          <div className="space-y-6 max-w-2xl">
            <div className="p-4 bg-white/5 rounded-xl">
              <h3 className="text-sm font-medium text-white/90 mb-4 flex items-center gap-2">
                <Webhook className="w-4 h-4" />
                WebSocket Configuration
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="text-xs text-white/50 block mb-1">Endpoint</label>
                  <code className="text-sm text-blue-400 bg-blue-500/10 px-3 py-2 rounded-lg block">
                    ws://localhost:7777/ai-events
                  </code>
                </div>
                <div>
                  <label className="text-xs text-white/50 block mb-1">HTTP API</label>
                  <code className="text-sm text-blue-400 bg-blue-500/10 px-3 py-2 rounded-lg block">
                    http://localhost:7777/api/ai-control
                  </code>
                </div>
              </div>
            </div>

            <div className="p-4 bg-white/5 rounded-xl">
              <h3 className="text-sm font-medium text-white/90 mb-4 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                Security
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-white/90">Authentication Required</div>
                    <div className="text-xs text-white/50">Require API key for external agents</div>
                  </div>
                  <button className="w-12 h-6 rounded-full bg-green-500">
                    <div className="w-5 h-5 rounded-full bg-white translate-x-6" />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-white/90">Rate Limiting</div>
                    <div className="text-xs text-white/50">Limit requests per minute</div>
                  </div>
                  <button className="w-12 h-6 rounded-full bg-green-500">
                    <div className="w-5 h-5 rounded-full bg-white translate-x-6" />
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 bg-white/5 rounded-xl">
              <h3 className="text-sm font-medium text-white/90 mb-4 flex items-center gap-2">
                <Key className="w-4 h-4" />
                API Keys
              </h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <div className="text-sm text-white/70">Default Key</div>
                  <div className="flex items-center gap-2">
                    <code className="text-xs text-white/50">••••••••••••</code>
                    <button className="p-1.5 rounded hover:bg-white/10 transition-all">
                      <Edit2 className="w-3 h-3 text-white/50" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add Route Modal */}
      {showAddRoute && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="w-full max-w-md bg-slate-900 rounded-xl border border-white/10 p-6">
            <h3 className="text-lg font-semibold text-white/90 mb-4">Add New Route</h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-white/70 block mb-1">Name</label>
                <input
                  type="text"
                  value={newRoute.name}
                  onChange={(e) => setNewRoute({ ...newRoute, name: e.target.value })}
                  placeholder="My AI Agent"
                  className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-white/90 placeholder:text-white/30"
                />
              </div>
              <div>
                <label className="text-sm text-white/70 block mb-1">Type</label>
                <div className="flex gap-2">
                  {(['local', 'cloud', 'hybrid'] as const).map((type) => (
                    <button
                      key={type}
                      onClick={() => setNewRoute({ ...newRoute, type })}
                      className={`flex-1 px-3 py-2 rounded-lg text-sm capitalize transition-all ${
                        newRoute.type === type
                          ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                          : 'bg-white/5 text-white/70 hover:bg-white/10'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm text-white/70 block mb-1">Endpoint</label>
                <input
                  type="text"
                  value={newRoute.endpoint}
                  onChange={(e) => setNewRoute({ ...newRoute, endpoint: e.target.value })}
                  placeholder="localhost:7777"
                  className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-white/90 placeholder:text-white/30"
                />
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button
                onClick={() => setShowAddRoute(false)}
                className="flex-1 px-4 py-2 bg-white/5 text-white/70 rounded-lg hover:bg-white/10 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={addRoute}
                className="flex-1 px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-all"
              >
                Add Route
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
