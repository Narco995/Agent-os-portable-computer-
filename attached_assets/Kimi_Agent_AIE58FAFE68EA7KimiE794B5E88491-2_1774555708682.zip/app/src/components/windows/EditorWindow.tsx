import { useState, useEffect } from 'react';
import { useFileSystem } from '@/hooks/useFileSystem';
import Editor from '@monaco-editor/react';
import {
  FileText,
  Save,
  Play,
  Folder,
  X,
} from 'lucide-react';

interface EditorWindowProps {
  windowId: string;
  onTitleChange: (title: string) => void;
  fileSystem: ReturnType<typeof useFileSystem>;
  initialFile?: string;
}

interface OpenFile {
  id: string;
  name: string;
  content: string;
  language: string;
  isModified: boolean;
}

const LANGUAGE_MAP: Record<string, string> = {
  js: 'javascript',
  ts: 'typescript',
  jsx: 'javascript',
  tsx: 'typescript',
  py: 'python',
  html: 'html',
  css: 'css',
  json: 'json',
  md: 'markdown',
  txt: 'plaintext',
  xml: 'xml',
  yaml: 'yaml',
  yml: 'yaml',
  sh: 'shell',
  bash: 'shell',
  rs: 'rust',
  go: 'go',
  java: 'java',
  cpp: 'cpp',
  c: 'c',
  cs: 'csharp',
  php: 'php',
  rb: 'ruby',
  swift: 'swift',
  kt: 'kotlin',
  sql: 'sql',
};

function getLanguage(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  return LANGUAGE_MAP[ext] || 'plaintext';
}

export function EditorWindow({ onTitleChange, fileSystem, initialFile }: EditorWindowProps) {
  const { files, readFile, writeFile, createFile } = fileSystem;
  const [openFiles, setOpenFiles] = useState<OpenFile[]>([]);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [showSidebar, setShowSidebar] = useState(true);

  // Open initial file
  useEffect(() => {
    if (initialFile && openFiles.length === 0) {
      const file = readFile(initialFile);
      if (file) {
        openFile(file);
      }
    }
  }, [initialFile]);

  const openFile = (file: { id: string; name: string; content?: string }) => {
    const existing = openFiles.find(f => f.id === file.id);
    if (existing) {
      setActiveFileId(file.id);
      onTitleChange(file.name);
      return;
    }

    const newFile: OpenFile = {
      id: file.id,
      name: file.name,
      content: file.content || '',
      language: getLanguage(file.name),
      isModified: false,
    };

    setOpenFiles([...openFiles, newFile]);
    setActiveFileId(file.id);
    onTitleChange(file.name);
  };

  const closeFile = (fileId: string) => {
    const newFiles = openFiles.filter(f => f.id !== fileId);
    setOpenFiles(newFiles);
    
    if (activeFileId === fileId) {
      const newActive = newFiles[newFiles.length - 1];
      setActiveFileId(newActive?.id || null);
      onTitleChange(newActive?.name || 'Text Editor');
    }
  };

  const updateFileContent = (fileId: string, content: string) => {
    setOpenFiles(prev => prev.map(f => 
      f.id === fileId ? { ...f, content, isModified: true } : f
    ));
  };

  const saveFile = (fileId: string) => {
    const file = openFiles.find(f => f.id === fileId);
    if (file) {
      writeFile(fileId, file.content);
      setOpenFiles(prev => prev.map(f => 
        f.id === fileId ? { ...f, isModified: false } : f
      ));
    }
  };

  const createNewFile = () => {
    const name = prompt('Enter file name:');
    if (name) {
      const id = createFile(name, '');
      const file = readFile(id);
      if (file) {
        openFile(file);
      }
    }
  };

  const activeFile = openFiles.find(f => f.id === activeFileId);

  // Filter files for explorer
  const codeFiles = files.filter(f => f.type === 'file');

  return (
    <div className="w-full h-full flex bg-[#1e1e1e]">
      {/* Sidebar */}
      {showSidebar && (
        <div className="w-64 bg-[#252526] border-r border-white/5 flex flex-col">
          <div className="p-4">
            <div className="text-sm font-semibold text-white/70 uppercase tracking-wider">Explorer</div>
          </div>
          <div className="flex-1 overflow-auto">
            <div className="px-2 py-1">
              <div className="text-xs text-white/50 mb-2 uppercase tracking-wider">Kimi OS</div>
              {codeFiles.map((file) => (
                <button
                  key={file.id}
                  onClick={() => openFile(file)}
                  className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm transition-all ${
                    activeFileId === file.id
                      ? 'bg-white/10 text-white/90'
                      : 'text-white/70 hover:bg-white/5'
                  }`}
                >
                  <FileText className="w-4 h-4 text-blue-400" />
                  <span className="truncate">{file.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col">
        {/* Tab Bar */}
        {openFiles.length > 0 && (
          <div className="flex items-center bg-[#2d2d2d] overflow-x-auto">
            {openFiles.map((file) => (
              <button
                key={file.id}
                onClick={() => {
                  setActiveFileId(file.id);
                  onTitleChange(file.name);
                }}
                className={`flex items-center gap-2 px-3 py-2 min-w-[100px] max-w-[200px] border-r border-white/5 transition-all ${
                  file.id === activeFileId
                    ? 'bg-[#1e1e1e]'
                    : 'bg-[#2d2d2d] hover:bg-[#333]'
                }`}
              >
                <FileText className="w-4 h-4 text-blue-400" />
                <span className="flex-1 text-xs text-white/90 truncate text-left">
                  {file.name}
                  {file.isModified && <span className="text-white/50"> ●</span>}
                </span>
                <X
                  className="w-3 h-3 text-white/50 hover:text-white/90"
                  onClick={() => closeFile(file.id)}
                />
              </button>
            ))}
          </div>
        )}

        {/* Toolbar */}
        <div className="flex items-center justify-between px-3 py-1.5 bg-[#252526] border-b border-white/5">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSidebar(!showSidebar)}
              className="p-1.5 rounded-lg hover:bg-white/10 transition-all"
            >
              <Folder className="w-4 h-4 text-white/70" />
            </button>
            <div className="w-px h-4 bg-white/10" />
            {activeFile && (
              <>
                <button
                  onClick={() => saveFile(activeFile.id)}
                  className="p-1.5 rounded-lg hover:bg-white/10 transition-all"
                  title="Save"
                >
                  <Save className="w-4 h-4 text-white/70" />
                </button>
                <button
                  className="p-1.5 rounded-lg hover:bg-white/10 transition-all"
                  title="Run"
                >
                  <Play className="w-4 h-4 text-green-400" />
                </button>
              </>
            )}
          </div>
          <div className="text-xs text-white/50">
            {activeFile?.language.toUpperCase() || 'Plain Text'}
          </div>
        </div>

        {/* Editor */}
        <div className="flex-1 overflow-hidden">
          {activeFile ? (
            <Editor
              height="100%"
              language={activeFile.language}
              value={activeFile.content}
              onChange={(value: string | undefined) => updateFileContent(activeFile.id, value || '')}
              theme="vs-dark"
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
                lineNumbers: 'on',
                roundedSelection: false,
                scrollBeyondLastLine: false,
                readOnly: false,
                automaticLayout: true,
                padding: { top: 16 },
              }}
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-white/30">
              <FileText className="w-16 h-16 mb-4 opacity-50" />
              <p>Select a file to start editing</p>
              <p className="text-sm mt-2">or create a new file</p>
              <button
                onClick={createNewFile}
                className="mt-4 px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-all"
              >
                New File
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
