import { useState } from 'react';
import { useFileSystem } from '@/hooks/useFileSystem';
import {
  Folder,
  FileText,
  Image,
  FileCode,
  ChevronLeft,
  Home,
  Plus,
  FolderPlus,
  FilePlus,
  Trash2,
  Edit3,
  Grid,
  List,
} from 'lucide-react';

interface FileManagerWindowProps {
  windowId: string;
  onTitleChange: (title: string) => void;
  fileSystem: ReturnType<typeof useFileSystem>;
}

const FILE_ICONS: Record<string, React.ReactNode> = {
  folder: <Folder className="w-10 h-10 text-yellow-400" />,
  file: <FileText className="w-10 h-10 text-blue-400" />,
  image: <Image className="w-10 h-10 text-purple-400" />,
  code: <FileCode className="w-10 h-10 text-orange-400" />,
};

function getFileIcon(name: string, type: 'file' | 'folder') {
  if (type === 'folder') return FILE_ICONS.folder;
  
  const ext = name.split('.').pop()?.toLowerCase();
  if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext || '')) return FILE_ICONS.image;
  if (['js', 'ts', 'jsx', 'tsx', 'py', 'html', 'css', 'json', 'md'].includes(ext || '')) return FILE_ICONS.code;
  return FILE_ICONS.file;
}

export function FileManagerWindow({ fileSystem }: FileManagerWindowProps) {
  const {
    getCurrentFolderContents,
    navigateToFolder,
    navigateUp,
    getBreadcrumb,
    createFile,
    createFolder,
    deleteItem,
    renameItem,
    readFile,
  } = fileSystem;

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [showNewMenu, setShowNewMenu] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; itemId: string } | null>(null);

  const items = getCurrentFolderContents();
  const breadcrumb = getBreadcrumb();

  const handleItemClick = (id: string, type: 'file' | 'folder') => {
    if (type === 'folder') {
      navigateToFolder(id);
    } else {
      // Open file in editor
      const file = readFile(id);
      if (file) {
        // Would open in editor window
      }
    }
    setSelectedItems(new Set([id]));
  };

  const handleItemDoubleClick = (id: string, type: 'file' | 'folder') => {
    if (type === 'folder') {
      navigateToFolder(id);
    }
  };

  const handleContextMenu = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({ x: e.clientX, y: e.clientY, itemId: id });
  };

  const startRename = (id: string, currentName: string) => {
    setRenamingId(id);
    setRenameValue(currentName);
    setContextMenu(null);
  };

  const confirmRename = () => {
    if (renamingId && renameValue.trim()) {
      renameItem(renamingId, renameValue.trim());
    }
    setRenamingId(null);
    setRenameValue('');
  };

  const handleDelete = (id: string) => {
    deleteItem(id);
    setContextMenu(null);
    setSelectedItems(prev => {
      const newSet = new Set(prev);
      newSet.delete(id);
      return newSet;
    });
  };

  return (
    <div className="w-full h-full flex flex-col bg-slate-900">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-800/50 border-b border-white/5">
        <div className="flex items-center gap-2">
          <button
            onClick={navigateUp}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-all"
          >
            <ChevronLeft className="w-4 h-4 text-white/70" />
          </button>
          <div className="flex items-center gap-1 text-sm text-white/70">
            <Home className="w-4 h-4" />
            {breadcrumb.map((item, i) => (
              <span key={item.id} className="flex items-center gap-1">
                <span className="text-white/30">/</span>
                <span className={i === breadcrumb.length - 1 ? 'text-white/90' : ''}>{item.name}</span>
              </span>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* New Button */}
          <div className="relative">
            <button
              onClick={() => setShowNewMenu(!showNewMenu)}
              className="flex items-center gap-1 px-3 py-1.5 bg-blue-500/20 text-blue-400 rounded-lg text-sm hover:bg-blue-500/30 transition-all"
            >
              <Plus className="w-4 h-4" />
              New
            </button>
            {showNewMenu && (
              <div className="absolute top-full right-0 mt-1 w-40 bg-slate-800 rounded-lg border border-white/10 shadow-xl overflow-hidden z-10">
                <button
                  onClick={() => {
                    createFolder('New Folder');
                    setShowNewMenu(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-white/90 hover:bg-white/10 transition-all"
                >
                  <FolderPlus className="w-4 h-4" />
                  New Folder
                </button>
                <button
                  onClick={() => {
                    createFile('New File.txt');
                    setShowNewMenu(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-white/90 hover:bg-white/10 transition-all"
                >
                  <FilePlus className="w-4 h-4" />
                  New File
                </button>
              </div>
            )}
          </div>

          {/* View Mode */}
          <div className="flex items-center bg-slate-800 rounded-lg p-0.5">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-md transition-all ${viewMode === 'grid' ? 'bg-white/10' : ''}`}
            >
              <Grid className="w-4 h-4 text-white/70" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-md transition-all ${viewMode === 'list' ? 'bg-white/10' : ''}`}
            >
              <List className="w-4 h-4 text-white/70" />
            </button>
          </div>
        </div>
      </div>

      {/* File List */}
      <div className="flex-1 overflow-auto p-4">
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-[repeat(auto-fill,minmax(100px,1fr))] gap-4">
            {items.map((item) => (
              <div
                key={item.id}
                onClick={() => handleItemClick(item.id, item.type)}
                onDoubleClick={() => handleItemDoubleClick(item.id, item.type)}
                onContextMenu={(e) => handleContextMenu(e, item.id)}
                className={`flex flex-col items-center gap-2 p-3 rounded-lg cursor-pointer transition-all ${
                  selectedItems.has(item.id)
                    ? 'bg-blue-500/20 border border-blue-500/30'
                    : 'hover:bg-white/5'
                }`}
              >
                {getFileIcon(item.name, item.type)}
                {renamingId === item.id ? (
                  <input
                    type="text"
                    value={renameValue}
                    onChange={(e) => setRenameValue(e.target.value)}
                    onBlur={confirmRename}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') confirmRename();
                      if (e.key === 'Escape') {
                        setRenamingId(null);
                        setRenameValue('');
                      }
                    }}
                    autoFocus
                    className="w-full px-1 py-0.5 bg-slate-800 border border-blue-500 rounded text-xs text-center text-white/90"
                    onClick={(e) => e.stopPropagation()}
                  />
                ) : (
                  <span className="text-xs text-white/80 text-center truncate w-full">{item.name}</span>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-1">
            {items.map((item) => (
              <div
                key={item.id}
                onClick={() => handleItemClick(item.id, item.type)}
                onDoubleClick={() => handleItemDoubleClick(item.id, item.type)}
                onContextMenu={(e) => handleContextMenu(e, item.id)}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer transition-all ${
                  selectedItems.has(item.id)
                    ? 'bg-blue-500/20'
                    : 'hover:bg-white/5'
                }`}
              >
                {getFileIcon(item.name, item.type)}
                <span className="flex-1 text-sm text-white/90">{item.name}</span>
                <span className="text-xs text-white/50">{item.type === 'file' ? `${item.size || 0} B` : '--'}</span>
                <span className="text-xs text-white/50">{item.modifiedAt.toLocaleDateString()}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Status Bar */}
      <div className="px-3 py-2 bg-slate-800/50 border-t border-white/5 text-xs text-white/50">
        {items.length} item{items.length !== 1 ? 's' : ''}
        {selectedItems.size > 0 && `, ${selectedItems.size} selected`}
      </div>

      {/* Context Menu */}
      {contextMenu && (
        <div
          className="fixed bg-slate-800 rounded-lg border border-white/10 shadow-xl overflow-hidden z-50 min-w-[140px]"
          style={{ left: contextMenu.x, top: contextMenu.y }}
          onClick={() => setContextMenu(null)}
        >
          <button
            onClick={() => {
              const item = items.find(i => i.id === contextMenu.itemId);
              if (item) startRename(item.id, item.name);
            }}
            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-white/90 hover:bg-white/10 transition-all"
          >
            <Edit3 className="w-4 h-4" />
            Rename
          </button>
          <button
            onClick={() => handleDelete(contextMenu.itemId)}
            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-500/10 transition-all"
          >
            <Trash2 className="w-4 h-4" />
            Delete
          </button>
        </div>
      )}
    </div>
  );
}
