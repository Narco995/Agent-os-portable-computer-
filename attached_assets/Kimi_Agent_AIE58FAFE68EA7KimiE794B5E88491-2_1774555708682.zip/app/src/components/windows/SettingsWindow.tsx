import { useState } from 'react';
import { useHardwareMonitor } from '@/hooks/useHardwareMonitor';
import { useAIAgentControl } from '@/hooks/useAIAgentControl';
import {
  Settings,
  Monitor,
  Cpu,
  Globe,
  Shield,
  Save,
  Check,
  AlertCircle,
} from 'lucide-react';

interface SettingsWindowProps {
  windowId: string;
  onTitleChange: (title: string) => void;
  hardware: ReturnType<typeof useHardwareMonitor>;
  aiControl: ReturnType<typeof useAIAgentControl>;
}

type SettingsTab = 'general' | 'display' | 'compute' | 'ai' | 'network' | 'security';

export function SettingsWindow({ hardware, aiControl }: SettingsWindowProps) {
  const [activeTab, setActiveTab] = useState<SettingsTab>('general');
  const [settings, setSettings] = useState({
    theme: 'dark',
    accentColor: 'blue',
    transparency: true,
    animations: true,
    notifications: true,
    autoSave: true,
    computeMode: hardware.computeMode,
    defaultBrowser: 'kimi',
    terminalShell: 'bash',
    aiAutoComplete: true,
    aiSuggestions: true,
    networkProxy: '',
    apiPort: 7777,
  });
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const tabs = [
    { id: 'general' as SettingsTab, icon: Settings, label: 'General' },
    { id: 'display' as SettingsTab, icon: Monitor, label: 'Display' },
    { id: 'compute' as SettingsTab, icon: Cpu, label: 'Compute' },
    { id: 'ai' as SettingsTab, icon: Globe, label: 'AI Control' },
    { id: 'network' as SettingsTab, icon: Globe, label: 'Network' },
    { id: 'security' as SettingsTab, icon: Shield, label: 'Security' },
  ];

  return (
    <div className="w-full h-full flex bg-slate-900">
      {/* Sidebar */}
      <div className="w-56 bg-slate-800/50 border-r border-white/5">
        <div className="p-4">
          <h2 className="text-lg font-semibold text-white/90">Settings</h2>
          <p className="text-xs text-white/50 mt-1">Configure your system</p>
        </div>
        <nav className="px-2 pb-4">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                activeTab === tab.id
                  ? 'bg-blue-500/20 text-blue-400'
                  : 'text-white/70 hover:bg-white/5'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-2xl mx-auto p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-white/90">
              {tabs.find(t => t.id === activeTab)?.label}
            </h1>
            <button
              onClick={handleSave}
              className="flex items-center gap-2 px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-all"
            >
              {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              {saved ? 'Saved' : 'Save Changes'}
            </button>
          </div>

          {/* General Settings */}
          {activeTab === 'general' && (
            <div className="space-y-6">
              <div className="p-4 bg-white/5 rounded-lg">
                <h3 className="text-sm font-medium text-white/90 mb-4">System</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-white/90">Auto-save</div>
                      <div className="text-xs text-white/50">Automatically save files</div>
                    </div>
                    <button
                      onClick={() => setSettings(s => ({ ...s, autoSave: !s.autoSave }))}
                      className={`w-12 h-6 rounded-full transition-all ${
                        settings.autoSave ? 'bg-blue-500' : 'bg-white/20'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white transition-all ${
                        settings.autoSave ? 'translate-x-6' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-white/90">Notifications</div>
                      <div className="text-xs text-white/50">Show system notifications</div>
                    </div>
                    <button
                      onClick={() => setSettings(s => ({ ...s, notifications: !s.notifications }))}
                      className={`w-12 h-6 rounded-full transition-all ${
                        settings.notifications ? 'bg-blue-500' : 'bg-white/20'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white transition-all ${
                        settings.notifications ? 'translate-x-6' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-white/5 rounded-lg">
                <h3 className="text-sm font-medium text-white/90 mb-4">About</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/50">Version</span>
                    <span className="text-white/90">2.0.0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50">Build</span>
                    <span className="text-white/90">2024.03.26</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50">Kernel</span>
                    <span className="text-white/90">Kimi OS 6.8.0</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Display Settings */}
          {activeTab === 'display' && (
            <div className="space-y-6">
              <div className="p-4 bg-white/5 rounded-lg">
                <h3 className="text-sm font-medium text-white/90 mb-4">Appearance</h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-white/70 block mb-2">Theme</label>
                    <div className="flex gap-2">
                      {['dark', 'light', 'auto'].map((theme) => (
                        <button
                          key={theme}
                          onClick={() => setSettings(s => ({ ...s, theme }))}
                          className={`px-4 py-2 rounded-lg text-sm capitalize transition-all ${
                            settings.theme === theme
                              ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                              : 'bg-white/5 text-white/70 hover:bg-white/10'
                          }`}
                        >
                          {theme}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-white/70 block mb-2">Accent Color</label>
                    <div className="flex gap-2">
                      {['blue', 'purple', 'green', 'orange', 'pink'].map((color) => (
                        <button
                          key={color}
                          onClick={() => setSettings(s => ({ ...s, accentColor: color }))}
                          className={`w-8 h-8 rounded-full transition-all ${
                            settings.accentColor === color ? 'ring-2 ring-white' : ''
                          }`}
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-white/90">Transparency Effects</div>
                      <div className="text-xs text-white/50">Enable blur and transparency</div>
                    </div>
                    <button
                      onClick={() => setSettings(s => ({ ...s, transparency: !s.transparency }))}
                      className={`w-12 h-6 rounded-full transition-all ${
                        settings.transparency ? 'bg-blue-500' : 'bg-white/20'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white transition-all ${
                        settings.transparency ? 'translate-x-6' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Compute Settings */}
          {activeTab === 'compute' && (
            <div className="space-y-6">
              <div className="p-4 bg-white/5 rounded-lg">
                <h3 className="text-sm font-medium text-white/90 mb-4">Compute Mode</h3>
                <div className="space-y-2">
                  {(['local', 'hybrid', 'cloud'] as const).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => {
                        setSettings(s => ({ ...s, computeMode: mode }));
                        hardware.setComputeMode(mode);
                      }}
                      className={`w-full flex items-center justify-between p-3 rounded-lg transition-all ${
                        settings.computeMode === mode
                          ? 'bg-blue-500/20 border border-blue-500/30'
                          : 'bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Cpu className={`w-5 h-5 ${
                          mode === 'local' ? 'text-green-400' :
                          mode === 'hybrid' ? 'text-yellow-400' : 'text-blue-400'
                        }`} />
                        <div className="text-left">
                          <div className="text-sm text-white/90 capitalize">{mode}</div>
                          <div className="text-xs text-white/50">
                            {mode === 'local' && 'Process everything locally'}
                            {mode === 'hybrid' && 'Balance between local and cloud'}
                            {mode === 'cloud' && 'Offload to cloud services'}
                          </div>
                        </div>
                      </div>
                      {settings.computeMode === mode && (
                        <div className="w-2 h-2 rounded-full bg-blue-400" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-4 bg-white/5 rounded-lg">
                <h3 className="text-sm font-medium text-white/90 mb-4">Hardware Info</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/50">CPU</span>
                    <span className="text-white/90">{hardware.stats.cpu.cores} Cores @ {hardware.stats.cpu.frequency.toFixed(1)} GHz</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50">Memory</span>
                    <span className="text-white/90">{hardware.stats.memory.total} GB</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50">Storage</span>
                    <span className="text-white/90">{hardware.stats.storage.total} GB SSD</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* AI Settings */}
          {activeTab === 'ai' && (
            <div className="space-y-6">
              <div className="p-4 bg-white/5 rounded-lg">
                <h3 className="text-sm font-medium text-white/90 mb-4">AI Agent Control</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-white/90">Allow External Agents</div>
                      <div className="text-xs text-white/50">Accept commands from external AI</div>
                    </div>
                    <button
                      onClick={() => aiControl.isListening ? aiControl.stopListening() : aiControl.startListening()}
                      className={`w-12 h-6 rounded-full transition-all ${
                        aiControl.isListening ? 'bg-green-500' : 'bg-white/20'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded-full bg-white transition-all ${
                        aiControl.isListening ? 'translate-x-6' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                  <div>
                    <label className="text-xs text-white/50 block mb-1">API Port</label>
                    <input
                      type="number"
                      value={settings.apiPort}
                      onChange={(e) => setSettings(s => ({ ...s, apiPort: parseInt(e.target.value) }))}
                      className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90"
                    />
                  </div>
                  <div className="p-3 bg-blue-500/10 rounded-lg">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-blue-400 mt-0.5" />
                      <div className="text-xs text-white/70">
                        External AI agents can connect via WebSocket at <code className="text-blue-400">ws://localhost:{settings.apiPort}/ai-events</code>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Network Settings */}
          {activeTab === 'network' && (
            <div className="space-y-6">
              <div className="p-4 bg-white/5 rounded-lg">
                <h3 className="text-sm font-medium text-white/90 mb-4">Connection</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-white/90">Status</div>
                      <div className="text-xs text-white/50">Network connectivity</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${hardware.stats.network.status === 'online' ? 'bg-green-400' : 'bg-red-400'}`} />
                      <span className="text-sm text-white/70 capitalize">{hardware.stats.network.status}</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-white/50 block mb-1">Proxy (optional)</label>
                    <input
                      type="text"
                      value={settings.networkProxy}
                      onChange={(e) => setSettings(s => ({ ...s, networkProxy: e.target.value }))}
                      placeholder="http://proxy.example.com:8080"
                      className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-lg text-sm text-white/90 placeholder:text-white/30"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Security Settings */}
          {activeTab === 'security' && (
            <div className="space-y-6">
              <div className="p-4 bg-white/5 rounded-lg">
                <h3 className="text-sm font-medium text-white/90 mb-4">Permissions</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-white/90">File System Access</div>
                      <div className="text-xs text-white/50">Allow AI to access files</div>
                    </div>
                    <button className="w-12 h-6 rounded-full bg-green-500">
                      <div className="w-5 h-5 rounded-full bg-white translate-x-6" />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-white/90">Browser Control</div>
                      <div className="text-xs text-white/50">Allow AI to control browser</div>
                    </div>
                    <button className="w-12 h-6 rounded-full bg-green-500">
                      <div className="w-5 h-5 rounded-full bg-white translate-x-6" />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-white/90">System Commands</div>
                      <div className="text-xs text-white/50">Allow AI to execute commands</div>
                    </div>
                    <button className="w-12 h-6 rounded-full bg-yellow-500">
                      <div className="w-5 h-5 rounded-full bg-white translate-x-0.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
