import { useState, useRef, useEffect } from 'react';
import { useAIAgentControl } from '@/hooks/useAIAgentControl';
import {
  Send,
  Bot,
  User,
  Sparkles,
  Settings,
  Plus,
  Copy,
  Check,
  Paperclip,
  Image as ImageIcon,
  Mic,
} from 'lucide-react';

interface AIChatWindowProps {
  windowId: string;
  onTitleChange: (title: string) => void;
  aiControl: ReturnType<typeof useAIAgentControl>;
}

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
}

interface ChatSession {
  id: string;
  name: string;
  messages: Message[];
}

export function AIChatWindow({ onTitleChange: _onTitleChange }: AIChatWindowProps) {
  const [sessions, setSessions] = useState<ChatSession[]>([
    { id: 'default', name: 'New Chat', messages: [] },
  ]);
  const [activeSessionId, setActiveSessionId] = useState('default');
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0];

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeSession.messages, isTyping]);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    // Add user message
    setSessions(prev => prev.map(s => 
      s.id === activeSessionId 
        ? { ...s, messages: [...s.messages, userMessage] }
        : s
    ));

    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "I can help you with that! Let me analyze your request.",
        "That's an interesting question. Here's what I think...",
        "I've processed your request. Here's my response:",
        "I understand. Let me provide you with a detailed answer.",
        "Great question! Here's what I found:",
      ];
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: responses[Math.floor(Math.random() * responses.length)] + "\n\nI'm Kimi, your AI assistant for this portable computer system. I can help you:\n\n• Control windows and applications\n• Browse the web\n• Manage files\n• Execute terminal commands\n• Monitor system resources\n• And much more!\n\nWhat would you like me to help you with?",
        timestamp: new Date(),
      };

      setSessions(prev => prev.map(s => 
        s.id === activeSessionId 
          ? { ...s, messages: [...s.messages, aiMessage] }
          : s
      ));
      setIsTyping(false);
    }, 1500);
  };

  const createNewChat = () => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      name: `Chat ${sessions.length + 1}`,
      messages: [],
    };
    setSessions([...sessions, newSession]);
    setActiveSessionId(newSession.id);
  };

  const copyMessage = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="w-full h-full flex bg-slate-900">
      {/* Sidebar */}
      <div className="w-64 bg-slate-800/50 border-r border-white/5 flex flex-col">
        <div className="p-3">
          <button
            onClick={createNewChat}
            className="w-full flex items-center gap-2 px-3 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-all"
          >
            <Plus className="w-4 h-4" />
            New Chat
          </button>
        </div>
        
        <div className="flex-1 overflow-auto px-2">
          <div className="text-xs text-white/50 uppercase tracking-wider px-2 mb-2">Recent</div>
          {sessions.map((session) => (
            <button
              key={session.id}
              onClick={() => setActiveSessionId(session.id)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all ${
                session.id === activeSessionId
                  ? 'bg-white/10 text-white/90'
                  : 'text-white/70 hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span className="truncate">{session.name}</span>
            </button>
          ))}
        </div>

        <div className="p-3 border-t border-white/5">
          <button className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-white/70 hover:bg-white/5 transition-all">
            <Settings className="w-4 h-4" />
            Settings
          </button>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-blue-400" />
            <span className="font-medium text-white/90">Kimi AI Assistant</span>
            <div className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded-full">
              Online
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-auto p-4 space-y-4">
          {activeSession.messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-white/30">
              <Bot className="w-16 h-16 mb-4" />
              <p className="text-lg font-medium">How can I help you today?</p>
              <p className="text-sm mt-2">Ask me anything or give me a task to complete</p>
              <div className="flex flex-wrap gap-2 mt-6 justify-center max-w-md">
                {[
                  'Open terminal',
                  'Show system stats',
                  'Browse to google.com',
                  'Create a new file',
                ].map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => {
                      setInput(suggestion);
                    }}
                    className="px-3 py-1.5 bg-white/5 text-white/70 rounded-full text-sm hover:bg-white/10 transition-all"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            activeSession.messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.role === 'user' ? 'bg-blue-500/20' : 'bg-purple-500/20'
                }`}>
                  {message.role === 'user' ? (
                    <User className="w-4 h-4 text-blue-400" />
                  ) : (
                    <Bot className="w-4 h-4 text-purple-400" />
                  )}
                </div>
                <div className={`max-w-[80%] ${message.role === 'user' ? 'items-end' : 'items-start'}`}>
                  <div className={`px-4 py-3 rounded-2xl ${
                    message.role === 'user'
                      ? 'bg-blue-500/20 text-white/90'
                      : 'bg-white/5 text-white/90'
                  }`}>
                    <div className="whitespace-pre-wrap">{message.content}</div>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-white/40">
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {message.role === 'assistant' && (
                      <button
                        onClick={() => copyMessage(message.content, message.id)}
                        className="p-1 rounded hover:bg-white/10 transition-all"
                      >
                        {copiedId === message.id ? (
                          <Check className="w-3 h-3 text-green-400" />
                        ) : (
                          <Copy className="w-3 h-3 text-white/40" />
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
          
          {isTyping && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                <Bot className="w-4 h-4 text-purple-400" />
              </div>
              <div className="px-4 py-3 rounded-2xl bg-white/5">
                <div className="flex gap-1">
                  <div className="w-2 h-2 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-white/5">
          <div className="flex items-end gap-2 bg-slate-800 rounded-xl p-2">
            <button className="p-2 rounded-lg hover:bg-white/10 transition-all">
              <Paperclip className="w-5 h-5 text-white/50" />
            </button>
            <button className="p-2 rounded-lg hover:bg-white/10 transition-all">
              <ImageIcon className="w-5 h-5 text-white/50" />
            </button>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder="Message Kimi..."
              className="flex-1 bg-transparent text-white/90 placeholder:text-white/30 resize-none outline-none py-2 max-h-32"
              rows={1}
              style={{ minHeight: '40px' }}
            />
            <button className="p-2 rounded-lg hover:bg-white/10 transition-all">
              <Mic className="w-5 h-5 text-white/50" />
            </button>
            <button
              onClick={sendMessage}
              disabled={!input.trim() || isTyping}
              className="p-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <div className="text-center mt-2">
            <span className="text-xs text-white/30">Kimi can make mistakes. Consider checking important information.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
