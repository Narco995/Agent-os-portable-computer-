import { useState, useRef, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import {
  Play,
  Save,
  FolderOpen,
  Plus,
  RotateCcw,
  Terminal,
  Settings,
  Package,
  Book,
  Download,
  Check,
} from 'lucide-react';

interface PythonWindowProps {
  windowId: string;
  onTitleChange: (title: string) => void;
}

const DEFAULT_CODE = `# Welcome to Python IDE in Kimi OS Portable!
# This is a full-featured Python development environment.

def greet(name):
    """A simple greeting function."""
    return f"Hello, {name}! Welcome to Kimi OS."

# Main execution
if __name__ == "__main__":
    print(greet("Developer"))
    
    # Try some Python features
    numbers = [1, 2, 3, 4, 5]
    squared = [n ** 2 for n in numbers]
    print(f"Numbers: {numbers}")
    print(f"Squared: {squared}")
    
    # AI Agent Integration Example
    print("\\n--- AI Agent Integration ---")
    print("You can control this portable computer via AI!")
`;

const SAMPLE_PACKAGES = [
  { name: 'numpy', installed: true, version: '1.24.3' },
  { name: 'pandas', installed: true, version: '2.0.2' },
  { name: 'requests', installed: true, version: '2.31.0' },
  { name: 'matplotlib', installed: false, version: null },
  { name: 'scipy', installed: false, version: null },
  { name: 'scikit-learn', installed: false, version: null },
  { name: 'tensorflow', installed: false, version: null },
  { name: 'torch', installed: false, version: null },
];

export function PythonWindow({}: PythonWindowProps) {
  const [code, setCode] = useState(DEFAULT_CODE);
  const [output, setOutput] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [packages, setPackages] = useState(SAMPLE_PACKAGES);
  const [activeTab, setActiveTab] = useState<'editor' | 'packages'>('editor');
  const outputRef = useRef<HTMLDivElement>(null);

  // Auto-scroll output
  useEffect(() => {
    outputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [output]);

  const runCode = async () => {
    setIsRunning(true);
    setOutput(prev => [...prev, '> Running...']);

    // Simulate Python execution
    setTimeout(() => {
      const simulatedOutput = [
        'Hello, Developer! Welcome to Kimi OS.',
        'Numbers: [1, 2, 3, 4, 5]',
        'Squared: [1, 4, 9, 16, 25]',
        '',
        '--- AI Agent Integration ---',
        'You can control this portable computer via AI!',
        '',
        'Process finished with exit code 0',
      ];
      
      setOutput(prev => [...prev.slice(0, -1), ...simulatedOutput]);
      setIsRunning(false);
    }, 1500);
  };

  const clearOutput = () => {
    setOutput([]);
  };

  const installPackage = (pkgName: string) => {
    setPackages(prev => prev.map(p => 
      p.name === pkgName ? { ...p, installed: true, version: 'latest' } : p
    ));
  };

  return (
    <div className="w-full h-full flex flex-col bg-[#1e1e1e]">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#252526] border-b border-white/5">
        <div className="flex items-center gap-2">
          <button
            onClick={runCode}
            disabled={isRunning}
            className="flex items-center gap-2 px-3 py-1.5 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 disabled:opacity-50 transition-all"
          >
            {isRunning ? (
              <div className="w-4 h-4 border-2 border-green-400 border-t-transparent rounded-full animate-spin" />
            ) : (
              <Play className="w-4 h-4" />
            )}
            Run
          </button>
          <div className="w-px h-5 bg-white/10" />
          <button className="p-1.5 rounded-lg hover:bg-white/10 transition-all">
            <Save className="w-4 h-4 text-white/70" />
          </button>
          <button className="p-1.5 rounded-lg hover:bg-white/10 transition-all">
            <FolderOpen className="w-4 h-4 text-white/70" />
          </button>
          <button className="p-1.5 rounded-lg hover:bg-white/10 transition-all">
            <Plus className="w-4 h-4 text-white/70" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('editor')}
            className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
              activeTab === 'editor' ? 'bg-white/10 text-white/90' : 'text-white/50 hover:bg-white/5'
            }`}
          >
            Editor
          </button>
          <button
            onClick={() => setActiveTab('packages')}
            className={`px-3 py-1.5 rounded-lg text-sm transition-all ${
              activeTab === 'packages' ? 'bg-white/10 text-white/90' : 'text-white/50 hover:bg-white/5'
            }`}
          >
            Packages
          </button>
          <button className="p-1.5 rounded-lg hover:bg-white/10 transition-all">
            <Settings className="w-4 h-4 text-white/70" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {activeTab === 'editor' ? (
          <>
            {/* Code Editor */}
            <div className="flex-1">
              <Editor
                height="100%"
                language="python"
                value={code}
                onChange={(value: string | undefined) => setCode(value || '')}
                theme="vs-dark"
                options={{
                  minimap: { enabled: true },
                  fontSize: 14,
                  fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
                  lineNumbers: 'on',
                  roundedSelection: false,
                  scrollBeyondLastLine: false,
                  automaticLayout: true,
                  padding: { top: 16 },
                  suggestOnTriggerCharacters: true,
                  quickSuggestions: true,
                }}
              />
            </div>

            {/* Output Panel */}
            <div className="w-80 bg-[#1e1e1e] border-l border-white/5 flex flex-col">
              <div className="flex items-center justify-between px-3 py-2 bg-[#252526] border-b border-white/5">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-white/70" />
                  <span className="text-sm text-white/90">Output</span>
                </div>
                <button
                  onClick={clearOutput}
                  className="p-1 rounded hover:bg-white/10 transition-all"
                >
                  <RotateCcw className="w-3 h-3 text-white/50" />
                </button>
              </div>
              <div className="flex-1 overflow-auto p-3 font-mono text-sm">
                {output.length === 0 ? (
                  <div className="text-white/30 italic">Click Run to execute your code...</div>
                ) : (
                  output.map((line, i) => (
                    <div
                      key={i}
                      className={`${
                        line.startsWith('>') ? 'text-blue-400' :
                        line.includes('exit code 0') ? 'text-green-400' :
                        line.includes('Error') ? 'text-red-400' :
                        'text-white/80'
                      }`}
                    >
                      {line}
                    </div>
                  ))
                )}
                <div ref={outputRef} />
              </div>
            </div>
          </>
        ) : (
          /* Packages View */
          <div className="flex-1 overflow-auto p-6">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-white/90">Python Packages</h2>
                  <p className="text-sm text-white/50">Manage your Python environment</p>
                </div>
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-all">
                  <Download className="w-4 h-4" />
                  Install Package
                </button>
              </div>

              <div className="grid gap-3">
                {packages.map((pkg) => (
                  <div
                    key={pkg.name}
                    className="flex items-center justify-between p-4 bg-white/5 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <Package className="w-5 h-5 text-yellow-400" />
                      <div>
                        <div className="text-sm font-medium text-white/90">{pkg.name}</div>
                        <div className="text-xs text-white/50">
                          {pkg.installed ? `v${pkg.version}` : 'Not installed'}
                        </div>
                      </div>
                    </div>
                    {pkg.installed ? (
                      <div className="flex items-center gap-2 text-green-400">
                        <Check className="w-4 h-4" />
                        <span className="text-sm">Installed</span>
                      </div>
                    ) : (
                      <button
                        onClick={() => installPackage(pkg.name)}
                        className="px-3 py-1.5 bg-blue-500/20 text-blue-400 rounded-lg text-sm hover:bg-blue-500/30 transition-all"
                      >
                        Install
                      </button>
                    )}
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 bg-blue-500/10 rounded-lg">
                <div className="flex items-start gap-3">
                  <Book className="w-5 h-5 text-blue-400 mt-0.5" />
                  <div>
                    <div className="text-sm font-medium text-white/90">Python Documentation</div>
                    <div className="text-xs text-white/50 mt-1">
                      Access the full Python documentation and tutorials directly from the IDE.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
