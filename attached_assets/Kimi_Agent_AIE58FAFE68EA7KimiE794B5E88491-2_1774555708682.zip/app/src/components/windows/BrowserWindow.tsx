import { useState, useRef } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Lock,
  Star,
  MoreVertical,
  Plus,
  X,
} from 'lucide-react';

interface BrowserWindowProps {
  windowId: string;
  onTitleChange: (title: string) => void;
  initialUrl?: string;
}

interface Tab {
  id: string;
  url: string;
  title: string;
  isLoading: boolean;
}

const DEFAULT_HOME = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      background: linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 100%);
      color: #e0e0ff;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin: 0;
      padding: 2rem;
    }
    .logo {
      font-size: 3rem;
      font-weight: bold;
      background: linear-gradient(135deg, #00d4ff, #8338ec);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 1rem;
    }
    .search-box {
      width: 100%;
      max-width: 600px;
      padding: 1rem 1.5rem;
      border-radius: 50px;
      border: 1px solid rgba(255,255,255,0.1);
      background: rgba(255,255,255,0.05);
      color: #e0e0ff;
      font-size: 1rem;
      outline: none;
    }
    .search-box:focus {
      border-color: #00d4ff;
    }
    .shortcuts {
      display: flex;
      gap: 1rem;
      margin-top: 2rem;
      flex-wrap: wrap;
      justify-content: center;
    }
    .shortcut {
      padding: 1rem 2rem;
      border-radius: 12px;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      color: #e0e0ff;
      text-decoration: none;
      transition: all 0.2s;
    }
    .shortcut:hover {
      background: rgba(0,212,255,0.1);
      border-color: #00d4ff;
    }
  </style>
</head>
<body>
  <div class="logo">Kimi Browser</div>
  <input type="text" class="search-box" placeholder="Search or enter address..." />
  <div class="shortcuts">
    <a href="https://google.com" class="shortcut">Google</a>
    <a href="https://github.com" class="shortcut">GitHub</a>
    <a href="https://kimi.com" class="shortcut">Kimi</a>
    <a href="https://stackoverflow.com" class="shortcut">Stack Overflow</a>
  </div>
</body>
</html>
`;

export function BrowserWindow({ initialUrl }: BrowserWindowProps) {
  const [tabs, setTabs] = useState<Tab[]>([
    { id: '1', url: initialUrl || 'about:home', title: 'New Tab', isLoading: false },
  ]);
  const [activeTabId, setActiveTabId] = useState('1');
  const [addressBar, setAddressBar] = useState(initialUrl || '');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  const navigate = (url: string) => {
    if (!url.startsWith('http') && !url.startsWith('about:')) {
      url = 'https://' + url;
    }

    setTabs(prev => prev.map(t => 
      t.id === activeTabId ? { ...t, url, isLoading: true } : t
    ));
    setAddressBar(url);

    // Add to history
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(url);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);

    // Simulate loading
    setTimeout(() => {
      setTabs(prev => prev.map(t => 
        t.id === activeTabId ? { ...t, isLoading: false } : t
      ));
    }, 500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(addressBar);
  };

  const createTab = () => {
    const newTab: Tab = {
      id: Date.now().toString(),
      url: 'about:home',
      title: 'New Tab',
      isLoading: false,
    };
    setTabs([...tabs, newTab]);
    setActiveTabId(newTab.id);
    setAddressBar('');
  };

  const closeTab = (tabId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) {
      setTabs([{ id: Date.now().toString(), url: 'about:home', title: 'New Tab', isLoading: false }]);
      setActiveTabId(tabs[0].id);
      return;
    }
    const newTabs = tabs.filter(t => t.id !== tabId);
    setTabs(newTabs);
    if (activeTabId === tabId) {
      setActiveTabId(newTabs[newTabs.length - 1].id);
    }
  };

  const goBack = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      const url = history[newIndex];
      setTabs(prev => prev.map(t => 
        t.id === activeTabId ? { ...t, url } : t
      ));
      setAddressBar(url);
    }
  };

  const goForward = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      const url = history[newIndex];
      setTabs(prev => prev.map(t => 
        t.id === activeTabId ? { ...t, url } : t
      ));
      setAddressBar(url);
    }
  };

  const refresh = () => {
    setTabs(prev => prev.map(t => 
      t.id === activeTabId ? { ...t, isLoading: true } : t
    ));
    setTimeout(() => {
      setTabs(prev => prev.map(t => 
        t.id === activeTabId ? { ...t, isLoading: false } : t
      ));
    }, 500);
  };

  const getDisplayUrl = (url: string) => {
    if (url === 'about:home') return '';
    return url;
  };

  const getIframeSrc = (url: string) => {
    if (url === 'about:home') {
      return `data:text/html,${encodeURIComponent(DEFAULT_HOME)}`;
    }
    return url;
  };

  return (
    <div className="w-full h-full flex flex-col bg-slate-900">
      {/* Tab Bar */}
      <div className="flex items-center bg-slate-800/50 border-b border-white/5">
        <div className="flex-1 flex items-center overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTabId(tab.id);
                setAddressBar(getDisplayUrl(tab.url));
              }}
              className={`flex items-center gap-2 px-3 py-2 min-w-[120px] max-w-[200px] border-r border-white/5 transition-all ${
                tab.id === activeTabId
                  ? 'bg-slate-900'
                  : 'bg-slate-800/50 hover:bg-slate-800'
              }`}
            >
              {tab.isLoading && (
                <div className="w-3 h-3 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
              )}
              <span className="flex-1 text-xs text-white/90 truncate text-left">{tab.title}</span>
              <X
                className="w-3 h-3 text-white/50 hover:text-white/90"
                onClick={(e) => closeTab(tab.id, e)}
              />
            </button>
          ))}
        </div>
        <button
          onClick={createTab}
          className="p-2 hover:bg-white/10 transition-all"
        >
          <Plus className="w-4 h-4 text-white/70" />
        </button>
      </div>

      {/* Address Bar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-slate-800/30 border-b border-white/5">
        <div className="flex items-center gap-1">
          <button
            onClick={goBack}
            disabled={historyIndex <= 0}
            className="p-1.5 rounded-lg hover:bg-white/10 disabled:opacity-30 transition-all"
          >
            <ArrowLeft className="w-4 h-4 text-white/70" />
          </button>
          <button
            onClick={goForward}
            disabled={historyIndex >= history.length - 1}
            className="p-1.5 rounded-lg hover:bg-white/10 disabled:opacity-30 transition-all"
          >
            <ArrowRight className="w-4 h-4 text-white/70" />
          </button>
          <button
            onClick={refresh}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-all"
          >
            <RotateCw className="w-4 h-4 text-white/70" />
          </button>
          <button
            onClick={() => navigate('about:home')}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-all"
          >
            <Home className="w-4 h-4 text-white/70" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 px-3 py-1.5 bg-slate-800 rounded-lg border border-white/10 focus-within:border-blue-500">
            <Lock className="w-3 h-3 text-green-400" />
            <input
              type="text"
              value={addressBar}
              onChange={(e) => setAddressBar(e.target.value)}
              placeholder="Search or enter address"
              className="flex-1 bg-transparent text-sm text-white/90 outline-none"
            />
            <Star className="w-4 h-4 text-white/30 hover:text-yellow-400 cursor-pointer transition-all" />
          </div>
        </form>

        <button className="p-1.5 rounded-lg hover:bg-white/10 transition-all">
          <MoreVertical className="w-4 h-4 text-white/70" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 bg-white">
        <iframe
          ref={iframeRef}
          src={getIframeSrc(activeTab.url)}
          className="w-full h-full border-none"
          sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
          title={activeTab.title}
        />
      </div>
    </div>
  );
}
