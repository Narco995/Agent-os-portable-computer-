import { useState, useRef, useEffect } from 'react';
import { useTerminal } from '@/hooks/useTerminal';
import { Plus, X } from 'lucide-react';

interface TerminalWindowProps {
  windowId: string;
  onTitleChange: (title: string) => void;
  terminal: ReturnType<typeof useTerminal>;
}

export function TerminalWindow({ terminal }: TerminalWindowProps) {
  const { sessions, activeSession, activeSessionId, setActiveSessionId, executeCommand, addOutput, createSession, closeSession, getPreviousCommand, getNextCommand } = terminal;
  const [input, setInput] = useState('');
  const [cursorVisible, setCursorVisible] = useState(true);
  const outputRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [activeSession?.history]);

  // Blink cursor
  useEffect(() => {
    const interval = setInterval(() => setCursorVisible(v => !v), 500);
    return () => clearInterval(interval);
  }, []);

  // Focus input on mount
  useEffect(() => {
    inputRef.current?.focus();
  }, [activeSessionId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Add command to history
    addOutput(`${activeSession?.currentPath || '/home/user'} $ ${input}`);

    // Execute command
    const result = executeCommand(input);
    
    if (result === '__CLEAR__') {
      // Clear handled in hook
    } else if (result === '__EXIT__') {
      // Close terminal
    } else if (result) {
      addOutput(result);
    }

    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      const prev = getPreviousCommand();
      if (prev) setInput(prev);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const next = getNextCommand();
      setInput(next);
    }
  };

  return (
    <div className="w-full h-full flex flex-col bg-[#0d0d0d] font-mono text-sm">
      {/* Session Tabs */}
      <div className="flex items-center gap-1 px-2 py-1 bg-[#1a1a1a] border-b border-white/5">
        {sessions.map((session) => (
          <button
            key={session.id}
            onClick={() => setActiveSessionId(session.id)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-all ${
              session.id === activeSessionId
                ? 'bg-[#2a2a2a] text-green-400'
                : 'text-white/50 hover:bg-white/5'
            }`}
          >
            <span>{session.name}</span>
            {sessions.length > 1 && (
              <X
                className="w-3 h-3 hover:text-red-400"
                onClick={(e) => {
                  e.stopPropagation();
                  closeSession(session.id);
                }}
              />
            )}
          </button>
        ))}
        <button
          onClick={() => createSession()}
          className="p-1.5 rounded-md text-white/50 hover:bg-white/10 transition-all"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Terminal Output */}
      <div
        ref={outputRef}
        className="flex-1 overflow-auto p-3 text-white/90"
        onClick={() => inputRef.current?.focus()}
      >
        {activeSession?.history.map((line, i) => (
          <div key={i} className="whitespace-pre-wrap break-all">
            {line.startsWith('/home') || line.startsWith('/') ? (
              <span>
                <span className="text-green-400">{line.split(' $ ')[0]}</span>
                <span className="text-white/90"> $ {line.split(' $ ')[1] || ''}</span>
              </span>
            ) : (
              <span className={line.startsWith('Error') ? 'text-red-400' : ''}>{line}</span>
            )}
          </div>
        ))}
      </div>

      {/* Input Line */}
      <form onSubmit={handleSubmit} className="flex items-center gap-2 px-3 py-2 bg-[#1a1a1a] border-t border-white/5">
        <span className="text-green-400 whitespace-nowrap">{activeSession?.currentPath || '/home/user'} $</span>
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          className="flex-1 bg-transparent text-white/90 outline-none"
          autoFocus
          spellCheck={false}
          autoComplete="off"
        />
        <span className={`w-2 h-4 bg-green-400 ${cursorVisible ? 'opacity-100' : 'opacity-0'}`} />
      </form>
    </div>
  );
}
